# @teamver/app-sdk

Fetch-based TypeScript client for Teamver main BE. Designed for AI Apps FE
(React/Next/Vite) so they stop re-implementing auth, workspace headers, snake/
camel conversion, refresh recovery and Drive presigned uploads.

Detailed design: [`docs/01_2_FE용_typescript_SDK_UI_상세_구현_설계.md`](../../../docs/01_2_FE용_typescript_SDK_UI_상세_구현_설계.md).

## Install

```bash
pnpm add @teamver/app-sdk
```

## Quickstart

```ts
import {
  TeamverClient,
  createLocalStorageTokenStore,
  createLocalStorageWorkspaceStore,
} from "@teamver/app-sdk";

const client = new TeamverClient({
  // Main BE API root. Host-only URLs auto-append /api.
  apiBaseUrl: "https://api.teamver.com",
  tokenStore: createLocalStorageTokenStore({ key: "teamver_access_token" }),
  workspaceStore: createLocalStorageWorkspaceStore({
    activeKey: "teamver_active_workspace_id",
    lastByUserKey: "teamver_last_workspace_by_user",
  }),
  onAuthExpired: () => window.location.assign("/auth/signin"),
});

const me = await client.user.getMe();
const { workspaces } = await client.workspace.listMine();
await client.workspaceStore?.set(workspaces[0].id);

const list = await client.drive.list({ folderId: null, limit: 50 });
const balance = await client.credits.balance();
```

## What it does

- `apiBaseUrl` normalisation (root → `/api`, relative `/be-api` preserved).
- `Authorization: Bearer` injection from `tokenStore`.
- `X-Workspace-Id` injection from `workspaceStore` (with per-request override).
- `X-Shared-Drive-Id` injection when `sharedDriveId` is passed.
- camelCase request body → snake_case + snake_case response → camelCase.
- 401 → `/auth/refresh` (de-duped) → retry once, then `onAuthExpired`.
- Drive presigned upload 3-step (`upload-request` → S3 PUT → `upload-confirm`).
- Typed error hierarchy: `AuthenticationError`, `ForbiddenError`,
  `QuotaExceededError`, `NotFoundError`, `RateLimitError`, `ValidationError`,
  `MainBEUnavailableError`, `NetworkError`, `LoginProviderMismatchError`.

## Scripts

```bash
pnpm --filter @teamver/app-sdk build
pnpm --filter @teamver/app-sdk test
pnpm --filter @teamver/app-sdk lint   # tsc --noEmit
```
