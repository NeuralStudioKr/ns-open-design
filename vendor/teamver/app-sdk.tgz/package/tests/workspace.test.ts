import { describe, expect, it, vi } from "vitest";
import { TeamverClient, createMemoryTokenStore, createMemoryWorkspaceStore } from "../src";

describe("WorkspaceClient", () => {
  it("listMine normalizes array/wrapped shapes and skips workspace header", async () => {
    const fetchImpl: typeof fetch = vi.fn(async (input: RequestInfo | URL, init: RequestInit = {}) => {
      const url = typeof input === "string" ? input : input.toString();
      expect(new Headers(init.headers).get("x-workspace-id")).toBeNull();
      if (url.endsWith("/v2/workspace/me")) {
        return new Response(
          JSON.stringify({ workspaces: [{ id: "WS-1", name: "A", role: "owner" }] }),
          { status: 200, headers: { "content-type": "application/json" } },
        );
      }
      if (url.endsWith("/v2/workspace/settings/list")) {
        return new Response(JSON.stringify([{ id: "WS-2", name: "B", role: "admin" }]), {
          status: 200,
          headers: { "content-type": "application/json" },
        });
      }
      return new Response("{}", { status: 200, headers: { "content-type": "application/json" } });
    }) as unknown as typeof fetch;
    const c = new TeamverClient({
      apiBaseUrl: "https://api.example.com",
      fetch: fetchImpl,
      tokenStore: createMemoryTokenStore("t"),
      workspaceStore: createMemoryWorkspaceStore("WS-STORE"),
    });
    const mine = await c.workspace.listMine();
    expect(mine.workspaces).toHaveLength(1);
    const settings = await c.workspace.listForSettings();
    expect(settings.workspaces).toHaveLength(1);
    expect(settings.workspaces[0].id).toBe("WS-2");
  });

  it("get / membersOverview use the supplied workspaceId in the header", async () => {
    const calls: { url: string; headers: Headers }[] = [];
    const fetchImpl: typeof fetch = vi.fn(async (input: RequestInfo | URL, init: RequestInit = {}) => {
      const url = typeof input === "string" ? input : input.toString();
      calls.push({ url, headers: new Headers(init.headers) });
      return new Response(
        JSON.stringify({ id: "WS-1", name: "A", role: "owner", total_members: 3 }),
        { status: 200, headers: { "content-type": "application/json" } },
      );
    }) as unknown as typeof fetch;
    const c = new TeamverClient({
      apiBaseUrl: "https://api.example.com",
      fetch: fetchImpl,
      tokenStore: createMemoryTokenStore("t"),
      workspaceStore: createMemoryWorkspaceStore("WS-STORE"),
    });
    await c.workspace.get("WS-1");
    expect(calls[0].headers.get("x-workspace-id")).toBe("WS-1");

    await c.workspace.membersOverview("WS-1");
    expect(calls[1].url.endsWith("/v2/workspace/WS-1/members-overview")).toBe(true);
    expect(calls[1].headers.get("x-workspace-id")).toBe("WS-1");
  });

  it("leave sends delegate_to_user_id snake key", async () => {
    const captured: unknown[] = [];
    const fetchImpl: typeof fetch = vi.fn(async (_input: RequestInfo | URL, init: RequestInit = {}) => {
      captured.push(JSON.parse((init.body as string | undefined) ?? "{}"));
      return new Response(null, { status: 204 });
    }) as unknown as typeof fetch;
    const c = new TeamverClient({ apiBaseUrl: "https://api.example.com", fetch: fetchImpl });
    await c.workspace.leave("WS-1", { delegateToUserId: "USR-2" });
    expect(captured[0]).toEqual({ delegate_to_user_id: "USR-2" });
  });
});
