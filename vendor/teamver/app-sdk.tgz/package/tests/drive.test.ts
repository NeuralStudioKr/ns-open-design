import { describe, expect, it, vi } from "vitest";
import {
  TeamverApiError,
  TeamverClient,
  createMemoryTokenStore,
  createMemoryWorkspaceStore,
} from "../src";

interface CapturedCall {
  url: string;
  method: string;
  headers: Headers;
  body: unknown;
}

type Handler = (call: CapturedCall) => Response | Promise<Response>;

function makeFetch(handlers: Array<[string | RegExp, Handler]>) {
  const calls: CapturedCall[] = [];
  const fn: typeof fetch = vi.fn(async (input: RequestInfo | URL, init: RequestInit = {}) => {
    const url = typeof input === "string" ? input : input.toString();
    const method = (init.method ?? "GET").toUpperCase();
    let body: unknown = init.body;
    if (typeof body === "string") {
      try {
        body = JSON.parse(body);
      } catch {
        // keep raw text
      }
    }
    const call: CapturedCall = { url, method, headers: new Headers(init.headers), body };
    calls.push(call);
    for (const [match, handler] of handlers) {
      if (typeof match === "string" ? url.includes(match) : match.test(url)) {
        return await handler(call);
      }
    }
    return new Response("{}", { status: 200, headers: { "content-type": "application/json" } });
  }) as unknown as typeof fetch;
  return { fetch: fn, calls };
}

function jsonResponse(body: unknown, init: ResponseInit = {}) {
  const headers = new Headers(init.headers);
  if (!headers.has("content-type")) headers.set("content-type", "application/json");
  return new Response(JSON.stringify(body), { ...init, headers });
}

function makeClient(fetchImpl: typeof fetch) {
  return new TeamverClient({
    apiBaseUrl: "https://api.example.com",
    fetch: fetchImpl,
    tokenStore: createMemoryTokenStore("tok"),
    workspaceStore: createMemoryWorkspaceStore("WS-1"),
  });
}

describe("DriveClient.list", () => {
  it("snake-cases query, adds shared drive header and normalises items", async () => {
    const { fetch, calls } = makeFetch([
      [
        "/drive/list",
        () => jsonResponse({ items: [{ item_type: "asset", asset: { asset_id: "A", name: "n" } }] }),
      ],
    ]);
    const c = makeClient(fetch);
    const out = await c.drive.list({ folderId: "F-1", limit: 5, sharedDriveId: "SD-1" });
    expect(out.items).toHaveLength(1);
    expect(out.items[0].asset?.assetId).toBe("A");
    expect(calls[0].url).toBe(
      "https://api.example.com/api/drive/list?folder_id=F-1&limit=5",
    );
    expect(calls[0].headers.get("x-shared-drive-id")).toBe("SD-1");
  });

  it("array-style response shape is accepted", async () => {
    const { fetch } = makeFetch([
      ["/drive/list", () => jsonResponse([{ item_type: "folder", folder: { folder_id: "F", name: "n" } }])],
    ]);
    const c = makeClient(fetch);
    const out = await c.drive.list();
    expect(out.items).toHaveLength(1);
    expect(out.items[0].folder?.folderId).toBe("F");
  });
});

describe("DriveClient.folderTree", () => {
  it("normalises tree-wrapped response and uses long timeout", async () => {
    const { fetch } = makeFetch([
      [
        "/drive/folder/tree",
        () => jsonResponse({ tree: [{ folder_id: "F", name: "n", children: [] }] }),
      ],
    ]);
    const c = makeClient(fetch);
    const out = await c.drive.folderTree({ sharedDriveId: null });
    expect(out.tree[0].folderId).toBe("F");
  });
});

describe("DriveClient.homeSearch", () => {
  it("sends q + snake query and parses items", async () => {
    const { fetch, calls } = makeFetch([
      ["/v2/drive/home/search", () => jsonResponse({ items: [{ asset_id: "A", name: "n" }] })],
    ]);
    const c = makeClient(fetch);
    const out = await c.drive.homeSearch({ q: "report", sharedDriveId: "SD-1", limit: 3 });
    expect(out.items).toHaveLength(1);
    expect(calls[0].url).toContain("q=report");
    expect(calls[0].url).toContain("limit=3");
    expect(calls[0].headers.get("x-shared-drive-id")).toBe("SD-1");
  });
});

describe("DriveClient.getDownloadUrl + download", () => {
  it("returns the presigned URL response", async () => {
    const { fetch, calls } = makeFetch([
      [
        "/drive/asset/A/download-url",
        () => jsonResponse({ download_url: "https://s3/...", filename: "x.pdf" }),
      ],
    ]);
    const c = makeClient(fetch);
    const r = await c.drive.getDownloadUrl("A", { sharedDriveId: "SD-9" });
    expect(r.downloadUrl).toBe("https://s3/...");
    expect(r.filename).toBe("x.pdf");
    expect(calls[0].headers.get("x-shared-drive-id")).toBe("SD-9");
  });
});

describe("DriveClient.uploadFile (3-step)", () => {
  it("request → presigned PUT → confirm; returns asset; passes shared drive id", async () => {
    let s3Called = false;
    const { fetch, calls } = makeFetch([
      [
        "/drive/upload-request",
        (call) => {
          expect((call.body as Record<string, unknown>).filename).toBe("x.pdf");
          expect((call.body as Record<string, unknown>).shared_drive_id).toBe("SD-1");
          expect(call.headers.get("x-shared-drive-id")).toBe("SD-1");
          return jsonResponse({
            asset_id: "A-1",
            presigned_url: "https://s3/upload",
            method: "PUT",
          });
        },
      ],
      [
        "https://s3/upload",
        () => {
          s3Called = true;
          return new Response(null, { status: 200 });
        },
      ],
      [
        "/drive/upload-confirm",
        (call) => {
          expect((call.body as Record<string, unknown>).asset_id).toBe("A-1");
          return jsonResponse({
            asset: { asset_id: "A-1", name: "x.pdf", upload_status: "ready", size_bytes: 5 },
          });
        },
      ],
    ]);
    const c = makeClient(fetch);
    const file = new File([new Uint8Array([1, 2, 3, 4, 5])], "x.pdf", { type: "application/pdf" });
    const progress: number[] = [];
    const asset = await c.drive.uploadFile(file, {
      folderId: "F-1",
      sharedDriveId: "SD-1",
      onProgress: (p) => progress.push(p),
    });
    expect(s3Called).toBe(true);
    expect(asset.assetId).toBe("A-1");
    expect(asset.uploadStatus).toBe("ready");
    expect(progress.at(-1)).toBe(1);
    // 3 BE calls (request, confirm) + 1 S3 PUT
    expect(calls.filter((c) => c.url.includes("/api/drive/")).length).toBe(2);
  });

  it("does NOT confirm when S3 PUT fails", async () => {
    let confirmCalled = false;
    const { fetch } = makeFetch([
      [
        "/drive/upload-request",
        () => jsonResponse({ asset_id: "A-x", presigned_url: "https://s3/upload" }),
      ],
      ["https://s3/upload", () => new Response("fail", { status: 500 })],
      [
        "/drive/upload-confirm",
        () => {
          confirmCalled = true;
          return jsonResponse({});
        },
      ],
    ]);
    const c = makeClient(fetch);
    const file = new File([new Uint8Array([0])], "x.bin", { type: "application/octet-stream" });
    await expect(c.drive.uploadFile(file)).rejects.toBeInstanceOf(TeamverApiError);
    expect(confirmCalled).toBe(false);
  });

  it("treats 'already confirmed' 400 as idempotent success", async () => {
    const { fetch } = makeFetch([
      ["/drive/upload-request", () => jsonResponse({ asset_id: "A-2", presigned_url: "https://s3/u" })],
      ["https://s3/u", () => new Response(null, { status: 200 })],
      [
        "/drive/upload-confirm",
        () =>
          jsonResponse(
            { message: "error.drive.upload.already_confirmed" },
            { status: 400 },
          ),
      ],
    ]);
    const c = makeClient(fetch);
    const file = new File([new Uint8Array([0])], "x.bin", { type: "application/octet-stream" });
    const asset = await c.drive.uploadFile(file);
    expect(asset.assetId).toBe("A-2");
  });
});

describe("DriveClient.getSharing", () => {
  it("uses shared-drive scoped path when sharedDriveId is provided", async () => {
    const { fetch, calls } = makeFetch([
      [
        "/v2/shared-drive/SD-1/asset/A/sharing",
        () => jsonResponse({ asset_id: "A", visibility: "private" }),
      ],
    ]);
    const c = makeClient(fetch);
    const out = await c.drive.getSharing("A", { sharedDriveId: "SD-1" });
    expect(out.assetId).toBe("A");
    expect(calls[0].headers.get("x-shared-drive-id")).toBe("SD-1");
  });

  it("falls back to /drive/asset/{id}/sharing without shared drive", async () => {
    const { fetch, calls } = makeFetch([
      ["/drive/asset/A/sharing", () => jsonResponse({ asset_id: "A" })],
    ]);
    const c = makeClient(fetch);
    await c.drive.getSharing("A");
    expect(calls[0].url.endsWith("/api/drive/asset/A/sharing")).toBe(true);
    expect(calls[0].headers.get("x-shared-drive-id")).toBeNull();
  });
});
