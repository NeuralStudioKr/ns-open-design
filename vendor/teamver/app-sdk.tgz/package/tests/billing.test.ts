import { describe, expect, it, vi } from "vitest";
import {
  QuotaExceededError,
  TeamverClient,
  createMemoryTokenStore,
  createMemoryWorkspaceStore,
} from "../src";

interface Call {
  url: string;
  method: string;
  headers: Headers;
  body: unknown;
}

function makeFetch(routes: Array<[string, (call: Call) => Response]>) {
  const calls: Call[] = [];
  const fn: typeof fetch = vi.fn(async (input: RequestInfo | URL, init: RequestInit = {}) => {
    const url = typeof input === "string" ? input : input.toString();
    const method = (init.method ?? "GET").toUpperCase();
    let body: unknown = init.body;
    if (typeof body === "string") {
      try {
        body = JSON.parse(body);
      } catch {
        /* keep raw */
      }
    }
    const call: Call = { url, method, headers: new Headers(init.headers), body };
    calls.push(call);
    for (const [path, handler] of routes) {
      if (url.includes(path)) return handler(call);
    }
    return new Response("{}", { status: 200, headers: { "content-type": "application/json" } });
  }) as unknown as typeof fetch;
  return { fetch: fn, calls };
}

function jsonResponse(body: unknown, init: ResponseInit = {}) {
  const headers = new Headers(init.headers);
  if (!headers.has("content-type")) headers.set("content-type", "application/json");
  return new Response(JSON.stringify(body), { ...init, headers });
}

function makeClient(fetchImpl: typeof fetch, opts: { workspaceId?: string | null } = {}) {
  return new TeamverClient({
    apiBaseUrl: "https://api.example.com",
    fetch: fetchImpl,
    tokenStore: createMemoryTokenStore("tok"),
    workspaceStore: createMemoryWorkspaceStore(opts.workspaceId ?? "WS-1"),
  });
}

describe("CreditsClient", () => {
  it("balance hits /credits/balance and uses active workspace header", async () => {
    const { fetch, calls } = makeFetch([
      ["/credits/balance", () => jsonResponse({ workspace_id: "WS-1", balance: 100, currency: "KRW" })],
    ]);
    const c = makeClient(fetch);
    const r = await c.credits.balance();
    expect(r.balance).toBe(100);
    expect(r.workspaceId).toBe("WS-1");
    expect(calls[0].headers.get("x-workspace-id")).toBe("WS-1");
  });

  it("packs normalises {packs:[]}", async () => {
    const { fetch } = makeFetch([
      ["/credits/packs", () => jsonResponse({ packs: [{ id: "P1", name: "Pack 1", credits: 100, price_cents: 1000 }] })],
    ]);
    const c = makeClient(fetch);
    const out = await c.credits.packs();
    expect(out).toHaveLength(1);
    expect(out[0].priceCents).toBe(1000);
  });

  it("createOrder posts credit_pack_id snake key", async () => {
    const { fetch, calls } = makeFetch([
      ["/credits/orders", () => jsonResponse({ order_id: "O-1", payment_url: "https://pay" })],
    ]);
    const c = makeClient(fetch);
    const out = await c.credits.createOrder("PACK-1");
    expect(out.orderId).toBe("O-1");
    expect((calls[0].body as Record<string, unknown>).credit_pack_id).toBe("PACK-1");
  });

  it("confirmPayment threads payment_key snake key", async () => {
    const { fetch, calls } = makeFetch([
      ["/credits/confirm", () => jsonResponse({ order_id: "O-1", status: "paid" })],
    ]);
    const c = makeClient(fetch);
    const out = await c.credits.confirmPayment({ orderId: "O-1", paymentKey: "PK", amount: 1000 });
    expect(out.status).toBe("paid");
    expect((calls[0].body as Record<string, unknown>).payment_key).toBe("PK");
  });
});

describe("SubscriptionClient", () => {
  it("getMe skips workspace header by default", async () => {
    const { fetch, calls } = makeFetch([
      [
        "/subscription/me",
        () => jsonResponse({ plan_id: "free", plan_name: "Free", workspace_id: null }),
      ],
    ]);
    const c = makeClient(fetch, { workspaceId: "WS-STORE" });
    await c.subscription.getMe();
    expect(calls[0].headers.get("x-workspace-id")).toBeNull();
  });

  it("getMe attaches explicit workspaceId when caller passes one", async () => {
    const { fetch, calls } = makeFetch([
      ["/subscription/me", () => jsonResponse({ plan_id: "team", workspace_id: "WS-TEAM" })],
    ]);
    const c = makeClient(fetch, { workspaceId: "WS-STORE" });
    await c.subscription.getMe({ workspaceId: "WS-TEAM" });
    expect(calls[0].headers.get("x-workspace-id")).toBe("WS-TEAM");
  });

  it("createOrChange posts billing_cycle snake key", async () => {
    const { fetch, calls } = makeFetch([
      ["/subscription", () => jsonResponse({ plan_id: "team" })],
    ]);
    const c = makeClient(fetch);
    await c.subscription.createOrChange("team", "monthly");
    expect((calls[0].body as Record<string, unknown>).plan_id).toBe("team");
    expect((calls[0].body as Record<string, unknown>).billing_cycle).toBe("monthly");
  });
});

describe("BillingClient & quota error", () => {
  it("checkout POSTs with success_url/cancel_url snake keys", async () => {
    const { fetch, calls } = makeFetch([
      ["/billing/checkout", () => jsonResponse({ checkout_url: "https://pay/" })],
    ]);
    const c = makeClient(fetch);
    await c.billing.checkout({
      planId: "team",
      billingCycle: "yearly",
      successUrl: "https://app/s",
      cancelUrl: "https://app/c",
    });
    const body = calls[0].body as Record<string, unknown>;
    expect(body.plan_id).toBe("team");
    expect(body.billing_cycle).toBe("yearly");
    expect(body.success_url).toBe("https://app/s");
    expect(body.cancel_url).toBe("https://app/c");
  });

  it("QUOTA_EXCEEDED 403 is surfaced as QuotaExceededError with detail", async () => {
    const { fetch } = makeFetch([
      [
        "/credits/balance",
        () =>
          jsonResponse(
            {
              error: "QUOTA_EXCEEDED",
              detail: {
                quota_type: "insufficient_tokens",
                limit: 1000,
                current: 0,
                plan_name: "Free",
                upgrade_url: "https://t.com/upgrade",
              },
            },
            { status: 403 },
          ),
      ],
    ]);
    const c = makeClient(fetch);
    const err = await c.credits.balance().catch((e) => e);
    expect(err).toBeInstanceOf(QuotaExceededError);
    const q = err as QuotaExceededError;
    expect(q.quotaType).toBe("insufficient_tokens");
    expect(q.planName).toBe("Free");
    expect(q.upgradeUrl).toBe("https://t.com/upgrade");
  });
});
