import { describe, expect, it, vi } from "vitest";
import { TeamverClient, createMemoryTokenStore } from "../src";

function recordingFetch(handlers: Record<string, (init: RequestInit) => Response | Promise<Response>>) {
  const calls: { url: string; method: string; init: RequestInit }[] = [];
  const fn = vi.fn(async (input: RequestInfo | URL, init: RequestInit = {}): Promise<Response> => {
    const url = typeof input === "string" ? input : input.toString();
    const method = (init.method ?? "GET").toUpperCase();
    calls.push({ url, method, init });
    for (const [path, handler] of Object.entries(handlers)) {
      if (url.endsWith(path)) return await handler(init);
    }
    return new Response(JSON.stringify({}), { status: 200, headers: { "content-type": "application/json" } });
  });
  return { fetch: fn as unknown as typeof fetch, calls };
}

describe("AuthClient", () => {
  it("login: skips workspace + auth headers and sends snake body", async () => {
    const { fetch, calls } = recordingFetch({
      "/auth/login": () =>
        new Response(
          JSON.stringify({ access_token: "tok", user: { id: "u1", email: "a@x" } }),
          { status: 200, headers: { "content-type": "application/json" } },
        ),
    });
    const c = new TeamverClient({
      apiBaseUrl: "https://api.example.com",
      fetch,
      tokenStore: createMemoryTokenStore("OLD"),
    });
    const resp = await c.auth.login("a@x", "pw");
    expect(resp.accessToken).toBe("tok");
    expect(calls).toHaveLength(1);
    const h = new Headers(calls[0].init.headers);
    expect(h.get("authorization")).toBeNull();
    expect(h.get("x-workspace-id")).toBeNull();
    expect(JSON.parse(calls[0].init.body as string)).toEqual({ email: "a@x", password: "pw" });
  });

  it("loginOrg: hits /auth/login/org with workspace_id snake key", async () => {
    const { fetch, calls } = recordingFetch({
      "/auth/login/org": () =>
        new Response(JSON.stringify({ access_token: "tok" }), {
          status: 200,
          headers: { "content-type": "application/json" },
        }),
    });
    const c = new TeamverClient({ apiBaseUrl: "https://api.example.com", fetch });
    await c.auth.loginOrg({ workspaceId: "W-1", email: "a@x", password: "p" });
    expect(JSON.parse(calls[0].init.body as string)).toEqual({
      workspace_id: "W-1",
      email: "a@x",
      password: "p",
    });
  });

  it("logout posts to /auth/logout", async () => {
    const { fetch, calls } = recordingFetch({
      "/auth/logout": () =>
        new Response(JSON.stringify({ success: true }), {
          status: 200,
          headers: { "content-type": "application/json" },
        }),
    });
    const c = new TeamverClient({ apiBaseUrl: "https://api.example.com", fetch });
    const r = await c.auth.logout({ logoutRedirectUri: "/bye" });
    expect(r.success).toBe(true);
    expect(JSON.parse(calls[0].init.body as string)).toEqual({ logout_redirect_uri: "/bye" });
  });
});
