import { beforeEach, describe, expect, it } from "vitest";
import {
  createLocalStorageTokenStore,
  createLocalStorageWorkspaceStore,
  createMemoryTokenStore,
  createMemoryWorkspaceStore,
} from "../src/stores";

class MemoryStorage implements Storage {
  private data: Record<string, string> = {};
  get length(): number {
    return Object.keys(this.data).length;
  }
  key(i: number): string | null {
    return Object.keys(this.data)[i] ?? null;
  }
  getItem(k: string): string | null {
    return Object.prototype.hasOwnProperty.call(this.data, k) ? this.data[k] : null;
  }
  setItem(k: string, v: string): void {
    this.data[k] = v;
  }
  removeItem(k: string): void {
    delete this.data[k];
  }
  clear(): void {
    this.data = {};
  }
}

describe("token store", () => {
  let storage: MemoryStorage;
  beforeEach(() => {
    storage = new MemoryStorage();
  });

  it("localStorage token store roundtrips", () => {
    const s = createLocalStorageTokenStore({ storage, key: "tok" });
    expect(s.get()).toBeNull();
    s.set("hello");
    expect(s.get()).toBe("hello");
    s.set(null);
    expect(s.get()).toBeNull();
  });

  it("memory token store roundtrips", () => {
    const s = createMemoryTokenStore("init");
    expect(s.get()).toBe("init");
    s.set("next");
    expect(s.get()).toBe("next");
    s.set(null);
    expect(s.get()).toBeNull();
  });
});

describe("workspace store", () => {
  let storage: MemoryStorage;
  beforeEach(() => {
    storage = new MemoryStorage();
  });

  it("tracks active id and last-by-user with bootstrap fallback", () => {
    const s = createLocalStorageWorkspaceStore({ storage });
    expect(s.get()).toBeNull();
    s.set("WS-1");
    expect(s.get()).toBe("WS-1");
    s.setLastForUser("USR-1", "WS-2");
    expect(s.getLastForUser("USR-1")).toBe("WS-2");
    expect(s.getPreferredWorkspaceIdForBootstrap("USR-1")).toBe("WS-1");
    s.set(null);
    expect(s.getPreferredWorkspaceIdForBootstrap("USR-1")).toBe("WS-2");
    expect(s.getPreferredWorkspaceIdForBootstrap("USR-MISSING")).toBeNull();
  });

  it("memory workspace store can be cleared", () => {
    const s = createMemoryWorkspaceStore("X");
    expect(s.get()).toBe("X");
    s.set(null);
    expect(s.get()).toBeNull();
  });
});
