import { describe, expect, it, vi } from "vitest";
import { TeamverClient, createMemoryTokenStore } from "../src";

function recordingFetch(handlers: Record<string, (init: RequestInit) => Response | Promise<Response>>) {
  const calls: { url: string; method: string; init: RequestInit }[] = [];
  const fn = vi.fn(async (input: RequestInfo | URL, init: RequestInit = {}): Promise<Response> => {
    const url = typeof input === "string" ? input : input.toString();
    const method = (init.method ?? "GET").toUpperCase();
    calls.push({ url, method, init });
    for (const [path, handler] of Object.entries(handlers)) {
      if (url.includes(path)) return await handler(init);
    }
    return new Response(JSON.stringify({}), { status: 200, headers: { "content-type": "application/json" } });
  });
  return { fetch: fn as unknown as typeof fetch, calls };
}

const creds = { appId: "ai-slides", keyId: "key_1", accessKey: "tvk_live_secret" };

describe("AppServiceClient", () => {
  it("verifyContext sends registry headers and snake body", async () => {
    const { fetch, calls } = recordingFetch({
      "/app-service/context/verify": () =>
        new Response(
          JSON.stringify({
            user_id: "u1",
            workspace_id: "W-1",
            role: "member",
            app_id: "ai-slides",
            permissions: ["drive:read"],
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        ),
    });
    const c = new TeamverClient({
      apiBaseUrl: "https://api.example.com",
      fetch,
      tokenStore: createMemoryTokenStore("user-jwt"),
    });
    const resp = await c.appService.verifyContext({
      workspaceId: "W-1",
      appId: "ai-slides",
      credentials: creds,
    });
    expect(resp.userId).toBe("u1");
    expect(resp.permissions).toEqual(["drive:read"]);
    expect(calls).toHaveLength(1);
    const h = new Headers(calls[0].init.headers);
    expect(h.get("x-teamver-app-id")).toBe("ai-slides");
    expect(h.get("x-teamver-key-id")).toBe("key_1");
    expect(h.get("authorization")).toMatch(/Bearer user-jwt/);
    expect(JSON.parse(calls[0].init.body as string)).toEqual({
      workspace_id: "W-1",
      app_id: "ai-slides",
    });
  });

  it("heartbeat skips user auth header", async () => {
    const { fetch, calls } = recordingFetch({
      "/app-service/apps/ai-slides/heartbeat": () =>
        new Response(
          JSON.stringify({
            app_id: "ai-slides",
            status: "accepted",
            received_at: "2026-06-10T00:00:00+00:00",
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        ),
    });
    const c = new TeamverClient({
      apiBaseUrl: "https://api.example.com",
      fetch,
      tokenStore: createMemoryTokenStore("should-not-send"),
    });
    const resp = await c.appService.heartbeat("ai-slides", { status: "healthy", version: "1.0.0" }, creds);
    expect(resp.status).toBe("accepted");
    const h = new Headers(calls[0].init.headers);
    expect(h.get("authorization")).toBeNull();
    expect(h.get("x-teamver-access-key")).toBe("tvk_live_secret");
  });

  it("usageReport sends snake_case body without user auth", async () => {
    const { fetch, calls } = recordingFetch({
      "/app-service/apps/ai-slides/usage-report": () =>
        new Response(
          JSON.stringify({
            app_id: "ai-slides",
            status: "accepted",
            received_at: "2026-06-10T00:00:00+00:00",
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        ),
    });
    const c = new TeamverClient({
      apiBaseUrl: "https://api.example.com",
      fetch,
      tokenStore: createMemoryTokenStore("skip"),
    });
    const resp = await c.appService.usageReport(
      "ai-slides",
      {
        workspaceId: "ws_123",
        userId: "user_123",
        usageType: "ai_generation",
        quantity: 1,
        unit: "job",
        metadata: { input_tokens: 10 },
      },
      creds,
    );
    expect(resp.status).toBe("accepted");
    const h = new Headers(calls[0].init.headers);
    expect(h.get("authorization")).toBeNull();
    expect(JSON.parse(calls[0].init.body as string)).toMatchObject({
      workspace_id: "ws_123",
      user_id: "user_123",
      usage_type: "ai_generation",
    });
  });

  it("postEvent targets audit/events when audit option set", async () => {
    const { fetch, calls } = recordingFetch({
      "/audit/events": () =>
        new Response(
          JSON.stringify({
            app_id: "ai-slides",
            status: "accepted",
            received_at: "2026-06-10T00:00:00+00:00",
            event_id: "42",
          }),
          { status: 200, headers: { "content-type": "application/json" } },
        ),
    });
    const c = new TeamverClient({
      apiBaseUrl: "https://api.example.com",
      fetch,
      tokenStore: createMemoryTokenStore("skip"),
    });
    await c.appService.postEvent(
      {
        workspaceId: "ws_123",
        eventType: "app.slides.generated",
        appId: "ai-slides",
      },
      creds,
      { audit: true },
    );
    expect(calls[0].url).toContain("/audit/events");
  });
});
