import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  AuthenticationError,
  RateLimitError,
  TeamverApiError,
  TeamverClient,
  createMemoryTokenStore,
  createMemoryWorkspaceStore,
} from "../src";

interface RecordedCall {
  url: string;
  method: string;
  headers: Record<string, string>;
  body: unknown;
  credentials?: RequestCredentials | string;
}

interface MockResponseInit {
  status?: number;
  body?: unknown;
  bodyText?: string;
  contentType?: string;
  headers?: Record<string, string>;
}

function mockResponse(init: MockResponseInit = {}): Response {
  const status = init.status ?? 200;
  const contentType = init.contentType ?? (init.body !== undefined ? "application/json" : "");
  const body =
    init.bodyText !== undefined
      ? init.bodyText
      : init.body !== undefined
        ? JSON.stringify(init.body)
        : "";
  const headers = new Headers({ ...(init.headers ?? {}) });
  if (contentType) headers.set("content-type", contentType);
  return new Response(body, { status, headers });
}

function headersToObject(init: HeadersInit | undefined): Record<string, string> {
  const h = new Headers(init);
  const out: Record<string, string> = {};
  h.forEach((v, k) => {
    out[k.toLowerCase()] = v;
  });
  return out;
}

function makeRecordingFetch(handler: (call: RecordedCall) => Response | Promise<Response>) {
  const calls: RecordedCall[] = [];
  const fn = vi.fn(async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : (input as Request).url;
    const method = (init?.method ?? "GET").toUpperCase();
    let body: unknown = undefined;
    if (init?.body) {
      if (typeof init.body === "string") {
        try {
          body = JSON.parse(init.body);
        } catch {
          body = init.body;
        }
      } else {
        body = init.body;
      }
    }
    const call: RecordedCall = {
      url,
      method,
      headers: headersToObject(init?.headers),
      body,
      credentials: init?.credentials,
    };
    calls.push(call);
    return await handler(call);
  });
  return { fetch: fn as unknown as typeof fetch, calls };
}

function makeClient(opts: {
  fetch: typeof fetch;
  token?: string | null;
  workspaceId?: string | null;
  onAuthExpired?: () => void;
  refreshUrl?: string;
} = { fetch: globalThis.fetch }) {
  return new TeamverClient({
    apiBaseUrl: "https://api.example.com",
    refreshUrl: opts.refreshUrl,
    fetch: opts.fetch,
    tokenStore: createMemoryTokenStore(opts.token ?? null),
    workspaceStore: createMemoryWorkspaceStore(opts.workspaceId ?? null),
    onAuthExpired: opts.onAuthExpired,
    requestTimeoutMs: 1000,
  });
}

describe("TeamverHttpClient", () => {
  beforeEach(() => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  it("injects Bearer + workspace headers and uses credentials include", async () => {
    const { fetch, calls } = makeRecordingFetch(() =>
      mockResponse({ body: { user_id: "u1", first_name: "A" } }),
    );
    const c = makeClient({ fetch, token: "abc", workspaceId: "WS-1" });
    const out = await c.http.get("/user/me");
    expect(out).toBeUndefined; // result preview
    expect(calls).toHaveLength(1);
    expect(calls[0].url).toBe("https://api.example.com/api/user/me");
    expect(calls[0].headers["authorization"]).toBe("Bearer abc");
    expect(calls[0].headers["x-workspace-id"]).toBe("WS-1");
    expect(calls[0].credentials).toBe("include");
  });

  it("RequestOptions workspaceId wins over the store", async () => {
    const { fetch, calls } = makeRecordingFetch(() => mockResponse({ body: {} }));
    const c = makeClient({ fetch, token: "t", workspaceId: "STORE-WS" });
    await c.http.get("/v2/workspace/X", { workspaceId: "REQ-WS" });
    expect(calls[0].headers["x-workspace-id"]).toBe("REQ-WS");
  });

  it("skipWorkspaceIdHeader drops the header", async () => {
    const { fetch, calls } = makeRecordingFetch(() => mockResponse({ body: {} }));
    const c = makeClient({ fetch, token: "t", workspaceId: "STORE-WS" });
    await c.http.get("/user/me", { skipWorkspaceIdHeader: true });
    expect(calls[0].headers["x-workspace-id"]).toBeUndefined();
  });

  it("camel→snake on request, snake→camel on response", async () => {
    const { fetch, calls } = makeRecordingFetch(() =>
      mockResponse({ body: { asset_id: "X", upload_status: "ready" } }),
    );
    const c = makeClient({ fetch, token: "t" });
    const out = await c.http.post("/drive/upload-request", { filename: "x.pdf", folderId: "F-1" });
    expect(calls[0].body).toEqual({ filename: "x.pdf", folder_id: "F-1" });
    expect(out).toEqual({ assetId: "X", uploadStatus: "ready" });
  });

  it("query params are serialized with snake_case keys", async () => {
    const { fetch, calls } = makeRecordingFetch(() => mockResponse({ body: { items: [] } }));
    const c = makeClient({ fetch, token: "t" });
    await c.http.get("/drive/list", { query: { folderId: "F-1", limit: 10 } });
    expect(calls[0].url).toBe(
      "https://api.example.com/api/drive/list?folder_id=F-1&limit=10",
    );
  });

  it("Blob response bypasses transform", async () => {
    const blob = new Blob(["hi"], { type: "application/octet-stream" });
    const { fetch } = makeRecordingFetch(
      () =>
        new Response(blob, { status: 200, headers: { "content-type": "application/octet-stream" } }),
    );
    const c = makeClient({ fetch, token: "t" });
    const result = await c.http.get<Blob>("/raw");
    expect(result).toBeInstanceOf(Blob);
  });

  it("retries once with refreshed token on 401", async () => {
    let calls = 0;
    const recording = makeRecordingFetch((call) => {
      calls += 1;
      if (call.url.endsWith("/auth/refresh")) {
        return mockResponse({ body: { access_token: "new-token" } });
      }
      if (calls === 1) {
        return mockResponse({ status: 401, body: { message: "error.auth.expired" } });
      }
      return mockResponse({ body: { ok: true } });
    });
    const c = makeClient({ fetch: recording.fetch, token: "old", workspaceId: "WS-1" });
    const out = await c.http.get<{ ok: boolean }>("/v2/workspace/me");
    expect(out).toEqual({ ok: true });
    expect(await c.tokenStore?.get()).toBe("new-token");
    const lastCall = recording.calls[recording.calls.length - 1];
    expect(lastCall.headers["authorization"]).toBe("Bearer new-token");
  });

  it("uses refreshUrl override instead of apiBaseUrl for 401 recovery", async () => {
    let calls = 0;
    const recording = makeRecordingFetch((call) => {
      calls += 1;
      if (call.url === "https://main.example.com/api/auth/refresh") {
        return mockResponse({ body: { access_token: "new-token" } });
      }
      if (calls === 1) {
        return mockResponse({ status: 401, body: { message: "error.auth.expired" } });
      }
      return mockResponse({ body: { ok: true } });
    });
    const c = makeClient({
      fetch: recording.fetch,
      token: "old",
      refreshUrl: "https://main.example.com/api/auth/refresh",
    });
    await c.http.get<{ ok: boolean }>("/v2/workspace/me");
    expect(recording.calls.some((call) => call.url === "https://main.example.com/api/auth/refresh")).toBe(true);
    expect(recording.calls.some((call) => call.url.endsWith("api.example.com/api/auth/refresh"))).toBe(false);
  });

  it("throws AuthenticationError and calls onAuthExpired when refresh fails", async () => {
    let onExpired = 0;
    const { fetch } = makeRecordingFetch((call) => {
      if (call.url.endsWith("/auth/refresh")) {
        return mockResponse({ status: 401, body: { message: "expired" } });
      }
      return mockResponse({ status: 401, body: { message: "expired" } });
    });
    const c = makeClient({ fetch, token: "old", onAuthExpired: () => { onExpired += 1; } });
    await expect(c.http.get("/v2/workspace/me")).rejects.toBeInstanceOf(AuthenticationError);
    expect(onExpired).toBe(1);
  });

  it("does not refresh on auth endpoints themselves", async () => {
    const { fetch, calls } = makeRecordingFetch(() =>
      mockResponse({ status: 401, body: { message: "bad creds" } }),
    );
    const c = makeClient({ fetch });
    await expect(c.auth.login("a@x", "p")).rejects.toBeInstanceOf(AuthenticationError);
    expect(calls.filter((c) => c.url.endsWith("/auth/refresh"))).toHaveLength(0);
  });

  it("429 yields RateLimitError with retry-after", async () => {
    const { fetch } = makeRecordingFetch(() =>
      mockResponse({ status: 429, body: {}, headers: { "retry-after": "2" } }),
    );
    const c = makeClient({ fetch, token: "t" });
    const err = await c.http.get("/u").catch((e) => e);
    expect(err).toBeInstanceOf(RateLimitError);
    expect((err as RateLimitError).retryAfterMs).toBe(2000);
  });

  it("network errors → NetworkError", async () => {
    const fail = vi.fn(async () => {
      throw new TypeError("boom");
    }) as unknown as typeof fetch;
    const c = makeClient({ fetch: fail, token: "t" });
    const err = await c.http.get("/u").catch((e) => e);
    expect(err).toBeInstanceOf(TeamverApiError);
    expect((err as TeamverApiError).status).toBe(0);
    expect((err as TeamverApiError).code).toBe("NETWORK");
  });
});
