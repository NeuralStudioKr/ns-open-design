import { describe, expect, it } from "vitest";
import {
  DEFAULT_API_BASE_URL,
  TeamverClient,
  createMemoryTokenStore,
  createMemoryWorkspaceStore,
  createTeamverAppClient,
  normalizeApiBaseUrl,
} from "../src";

describe("normalizeApiBaseUrl", () => {
  it("adds /api when host root is given", () => {
    expect(normalizeApiBaseUrl("https://api.teamver.com")).toBe("https://api.teamver.com/api");
    expect(normalizeApiBaseUrl("https://api.teamver.com/")).toBe("https://api.teamver.com/api");
    expect(normalizeApiBaseUrl("http://localhost:8000")).toBe("http://localhost:8000/api");
  });

  it("keeps existing path", () => {
    expect(normalizeApiBaseUrl("https://api.teamver.com/api")).toBe("https://api.teamver.com/api");
  });

  it("preserves relative proxies", () => {
    expect(normalizeApiBaseUrl("/be-api")).toBe("/be-api");
    expect(normalizeApiBaseUrl("/be-api/")).toBe("/be-api");
    expect(normalizeApiBaseUrl("be-api")).toBe("/be-api");
  });

  it("falls back to default on empty input", () => {
    expect(normalizeApiBaseUrl(undefined)).toBe(DEFAULT_API_BASE_URL);
    expect(normalizeApiBaseUrl("")).toBe(DEFAULT_API_BASE_URL);
  });
});

describe("TeamverClient", () => {
  it("exposes domain wrappers and stores", () => {
    const tokenStore = createMemoryTokenStore("tok");
    const workspaceStore = createMemoryWorkspaceStore("WS-1");
    const client = new TeamverClient({
      apiBaseUrl: "https://api.teamver.com",
      tokenStore,
      workspaceStore,
    });
    expect(client.auth).toBeDefined();
    expect(client.user).toBeDefined();
    expect(client.workspace).toBeDefined();
    expect(client.drive).toBeDefined();
    expect(client.sharedDrive).toBeDefined();
    expect(client.billing).toBeDefined();
    expect(client.credits).toBeDefined();
    expect(client.subscription).toBeDefined();
    expect(client.tokenStore).toBe(tokenStore);
    expect(client.workspaceStore).toBe(workspaceStore);
  });

  it("createTeamverAppClient stays back-compatible", () => {
    const c = createTeamverAppClient({ apiBaseUrl: "https://example.com" });
    expect(c).toBeInstanceOf(TeamverClient);
    expect(c.config.apiBaseUrl).toContain("example.com");
  });
});
