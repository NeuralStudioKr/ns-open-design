import { describe, expect, it, vi } from "vitest";
import { TeamverClient, createMemoryTokenStore, createMemoryWorkspaceStore } from "../src";

describe("UserClient", () => {
  it("getMe skips X-Workspace-Id header by default", async () => {
    const calls: { url: string; headers: Headers }[] = [];
    const fetchImpl: typeof fetch = vi.fn(async (input: RequestInfo | URL, init: RequestInit = {}) => {
      const url = typeof input === "string" ? input : input.toString();
      calls.push({ url, headers: new Headers(init.headers) });
      return new Response(JSON.stringify({ id: "u1", email: "a@x", personal_workspace_id: "WS-P" }), {
        status: 200,
        headers: { "content-type": "application/json" },
      });
    }) as unknown as typeof fetch;
    const c = new TeamverClient({
      apiBaseUrl: "https://api.example.com",
      fetch: fetchImpl,
      tokenStore: createMemoryTokenStore("tok"),
      workspaceStore: createMemoryWorkspaceStore("WS-1"),
    });
    const me = await c.user.getMe();
    expect(me.personalWorkspaceId).toBe("WS-P");
    expect(calls[0].headers.get("x-workspace-id")).toBeNull();
    expect(calls[0].headers.get("authorization")).toBe("Bearer tok");
  });

  it("updateMe PATCHes the user id and snake-cases the payload", async () => {
    const captured: { url: string; method: string; body: unknown }[] = [];
    const fetchImpl: typeof fetch = vi.fn(async (input: RequestInfo | URL, init: RequestInit = {}) => {
      const url = typeof input === "string" ? input : input.toString();
      captured.push({
        url,
        method: (init.method ?? "GET").toUpperCase(),
        body: JSON.parse((init.body as string | undefined) ?? "{}"),
      });
      return new Response(JSON.stringify({ id: "u1", email: "a@x", image_path: "/p.png" }), {
        status: 200,
        headers: { "content-type": "application/json" },
      });
    }) as unknown as typeof fetch;
    const c = new TeamverClient({ apiBaseUrl: "https://api.example.com", fetch: fetchImpl });
    await c.user.updateMe("u1", { imagePath: "/p.png", name: "n" });
    expect(captured[0].method).toBe("PATCH");
    expect(captured[0].url).toBe("https://api.example.com/api/user/u1");
    expect(captured[0].body).toEqual({ image_path: "/p.png", name: "n" });
  });
});
