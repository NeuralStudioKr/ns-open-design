import { describe, expect, it } from "vitest";
import {
  AuthenticationError,
  ForbiddenError,
  LoginProviderMismatchError,
  MainBEUnavailableError,
  NotFoundError,
  QuotaExceededError,
  RateLimitError,
  TeamverApiError,
  ValidationError,
  mapHttpErrorBody,
} from "../src/errors";

function withHeaders(input: Record<string, string>): Headers {
  return new Headers(input);
}

describe("mapHttpErrorBody", () => {
  it("401 → AuthenticationError", () => {
    const e = mapHttpErrorBody({ status: 401, body: { message: "x" }, url: "/u", method: "GET" });
    expect(e).toBeInstanceOf(AuthenticationError);
    expect(e).toBeInstanceOf(TeamverApiError);
    expect(e.status).toBe(401);
  });

  it("403 + QUOTA_EXCEEDED → QuotaExceededError with snake/camel detail", () => {
    const e = mapHttpErrorBody({
      status: 403,
      body: {
        error: "QUOTA_EXCEEDED",
        detail: {
          quota_type: "insufficient_tokens",
          limit: 1000,
          current: 0,
          plan_name: "Free",
          upgrade_url: "https://teamver.com/upgrade",
        },
      },
      url: "/u",
      method: "POST",
    });
    expect(e).toBeInstanceOf(QuotaExceededError);
    expect(e).toBeInstanceOf(ForbiddenError);
    const q = e as QuotaExceededError;
    expect(q.quotaType).toBe("insufficient_tokens");
    expect(q.limit).toBe(1000);
    expect(q.planName).toBe("Free");
    expect(q.upgradeUrl).toBe("https://teamver.com/upgrade");
  });

  it("403 plain → ForbiddenError", () => {
    const e = mapHttpErrorBody({ status: 403, body: { message: "no" }, url: "/u", method: "GET" });
    expect(e).toBeInstanceOf(ForbiddenError);
    expect(e).not.toBeInstanceOf(QuotaExceededError);
  });

  it("404 → NotFoundError", () => {
    const e = mapHttpErrorBody({ status: 404, body: {}, url: "/u", method: "GET" });
    expect(e).toBeInstanceOf(NotFoundError);
  });

  it("429 → RateLimitError with retry-after seconds", () => {
    const e = mapHttpErrorBody({
      status: 429,
      body: {},
      url: "/u",
      method: "GET",
      headers: withHeaders({ "retry-after": "5" }),
    });
    expect(e).toBeInstanceOf(RateLimitError);
    expect((e as RateLimitError).retryAfterMs).toBe(5000);
  });

  it("500 → MainBEUnavailableError", () => {
    const e = mapHttpErrorBody({ status: 503, body: {}, url: "/u", method: "GET" });
    expect(e).toBeInstanceOf(MainBEUnavailableError);
  });

  it("400 with plain detail string → ValidationError preserving message", () => {
    const e = mapHttpErrorBody({
      status: 400,
      body: { detail: "field required" },
      url: "/u",
      method: "POST",
    });
    expect(e).toBeInstanceOf(ValidationError);
    expect(e.message).toBe("field required");
  });

  it("login_provider.not_valid → LoginProviderMismatchError", () => {
    const e = mapHttpErrorBody({
      status: 400,
      body: {
        message: "error.login_provider.not_valid.GOOGLE",
        params: { oauthCallbackPath: "/api/auth/callback/google" },
      },
      url: "/u",
      method: "POST",
    });
    expect(e).toBeInstanceOf(LoginProviderMismatchError);
    const l = e as LoginProviderMismatchError;
    expect(l.expectedLoginProvider).toBe("GOOGLE");
    expect(l.oauthCallbackPath).toBe("/api/auth/callback/google");
  });
});
