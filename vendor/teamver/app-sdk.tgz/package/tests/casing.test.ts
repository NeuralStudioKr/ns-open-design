import { describe, expect, it } from "vitest";
import {
  buildSnakeSearchParams,
  camelToSnakeDeep,
  snakeCaseFormData,
  snakeToCamelDeep,
  toCamelKey,
  toSnakeKey,
} from "../src/casing";

describe("casing", () => {
  it("toSnakeKey/toCamelKey are inverse on flat names", () => {
    const samples = ["userId", "imagePath", "s3ImageUrl", "isAccountDefaultWorkspace"];
    for (const s of samples) {
      expect(toCamelKey(toSnakeKey(s))).toBe(s);
    }
  });

  it("camelToSnakeDeep walks nested objects/arrays", () => {
    const input = {
      userId: "u1",
      nested: { firstName: "a", listItems: [{ assetId: "x", sharedDriveId: "y" }] },
    };
    expect(camelToSnakeDeep(input)).toEqual({
      user_id: "u1",
      nested: { first_name: "a", list_items: [{ asset_id: "x", shared_drive_id: "y" }] },
    });
  });

  it("snakeToCamelDeep walks nested objects/arrays", () => {
    const input = {
      user_id: "u1",
      list_items: [{ asset_id: "x", upload_status: "ready" }],
    };
    expect(snakeToCamelDeep(input)).toEqual({
      userId: "u1",
      listItems: [{ assetId: "x", uploadStatus: "ready" }],
    });
  });

  it("does not mangle Blob/FormData values", () => {
    const blob = new Blob(["a"], { type: "text/plain" });
    const fd = new FormData();
    fd.append("fileBlob", blob);
    fd.append("ownerId", "u1");
    const out = snakeCaseFormData(fd);
    const keys: string[] = [];
    out.forEach((_v, k) => keys.push(k));
    expect(keys.sort()).toEqual(["file_blob", "owner_id"]);
    expect(out.get("file_blob")).toBeInstanceOf(Blob);
  });

  it("buildSnakeSearchParams produces snake_case keys and skips null/undefined", () => {
    const p = buildSnakeSearchParams({ folderId: "F", sharedDriveId: null, limit: 10, drop: undefined });
    expect(p?.toString()).toBe("folder_id=F&limit=10");
  });
});
