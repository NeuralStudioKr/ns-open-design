import type { TeamverHttpClient } from "./http";
import type { RequestOptions, UpdateUserPayload, User } from "./types";

/**
 * `/api/user/*` wrapper.
 *
 * `getMe()` MUST skip the `X-Workspace-Id` header by default. A stale workspace
 * id (e.g. one the user no longer belongs to) makes the call 403 in main BE,
 * which would break the entire app bootstrap.
 */
export class UserClient {
  constructor(private readonly http: TeamverHttpClient) {}

  async getMe(options: RequestOptions = {}): Promise<User> {
    return this.http.get<User>("/user/me", {
      skipWorkspaceIdHeader: true,
      ...options,
    });
  }

  async updateMe(
    userId: string,
    payload: UpdateUserPayload,
    options: RequestOptions = {},
  ): Promise<User> {
    return this.http.patch<User>(`/user/${encodeURIComponent(userId)}`, payload, {
      skipWorkspaceIdHeader: true,
      ...options,
    });
  }
}
