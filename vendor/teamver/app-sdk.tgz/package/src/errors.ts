/**
 * SDK error hierarchy.
 *
 * - Mirrors the response shapes documented in `01_2_FE용_typescript_SDK_UI_상세_구현_설계.md`
 *   section 11 (error design).
 * - Public errors must be `instanceof TeamverApiError`, and HTTP-status-derived
 *   errors carry a stable `status` field for `try { ... } catch (e: TeamverApiError)`.
 */

export interface TeamverApiErrorInit {
  status: number;
  code?: string;
  messageKey?: string;
  message?: string;
  params?: Record<string, unknown>;
  requestId?: string;
  responseBody?: unknown;
  cause?: unknown;
}

export class TeamverApiError extends Error {
  readonly status: number;
  readonly code?: string;
  readonly messageKey?: string;
  readonly params?: Record<string, unknown>;
  readonly requestId?: string;
  readonly responseBody?: unknown;

  constructor(init: TeamverApiErrorInit) {
    super(init.message ?? init.messageKey ?? init.code ?? `HTTP ${init.status}`);
    this.name = "TeamverApiError";
    this.status = init.status;
    this.code = init.code;
    this.messageKey = init.messageKey;
    this.params = init.params;
    this.requestId = init.requestId;
    this.responseBody = init.responseBody;
    if (init.cause !== undefined) {
      (this as { cause?: unknown }).cause = init.cause;
    }
    // Keep `instanceof` correct under transpilation.
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export class AuthenticationError extends TeamverApiError {
  constructor(init: TeamverApiErrorInit) {
    super(init);
    this.name = "AuthenticationError";
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export class ForbiddenError extends TeamverApiError {
  constructor(init: TeamverApiErrorInit) {
    super(init);
    this.name = "ForbiddenError";
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export interface QuotaExceededInit extends TeamverApiErrorInit {
  quotaType?: string;
  limit?: number;
  current?: number;
  planName?: string;
  upgradeUrl?: string;
}

export class QuotaExceededError extends ForbiddenError {
  readonly quotaType?: string;
  readonly limit?: number;
  readonly current?: number;
  readonly planName?: string;
  readonly upgradeUrl?: string;

  constructor(init: QuotaExceededInit) {
    super(init);
    this.name = "QuotaExceededError";
    this.quotaType = init.quotaType;
    this.limit = init.limit;
    this.current = init.current;
    this.planName = init.planName;
    this.upgradeUrl = init.upgradeUrl;
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export class NotFoundError extends TeamverApiError {
  constructor(init: TeamverApiErrorInit) {
    super(init);
    this.name = "NotFoundError";
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export class RateLimitError extends TeamverApiError {
  readonly retryAfterMs?: number;

  constructor(init: TeamverApiErrorInit & { retryAfterMs?: number }) {
    super(init);
    this.name = "RateLimitError";
    this.retryAfterMs = init.retryAfterMs;
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export class ValidationError extends TeamverApiError {
  constructor(init: TeamverApiErrorInit) {
    super(init);
    this.name = "ValidationError";
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export class MainBEUnavailableError extends TeamverApiError {
  constructor(init: TeamverApiErrorInit) {
    super(init);
    this.name = "MainBEUnavailableError";
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export class NetworkError extends TeamverApiError {
  constructor(init: Partial<TeamverApiErrorInit> & { message: string }) {
    super({ status: 0, ...init });
    this.name = "NetworkError";
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export interface LoginProviderMismatchInit extends TeamverApiErrorInit {
  expectedLoginProvider?: "GOOGLE" | "KAKAO" | "EMAIL" | string;
  oauthCallbackPath?: string | null;
  emailLoginPath?: string | null;
  organizationEmailLoginPath?: string | null;
}

export class LoginProviderMismatchError extends TeamverApiError {
  readonly expectedLoginProvider?: string;
  readonly oauthCallbackPath?: string | null;
  readonly emailLoginPath?: string | null;
  readonly organizationEmailLoginPath?: string | null;

  constructor(init: LoginProviderMismatchInit) {
    super(init);
    this.name = "LoginProviderMismatchError";
    this.expectedLoginProvider = init.expectedLoginProvider;
    this.oauthCallbackPath = init.oauthCallbackPath ?? null;
    this.emailLoginPath = init.emailLoginPath ?? null;
    this.organizationEmailLoginPath = init.organizationEmailLoginPath ?? null;
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

// ---------------------------------------------------------------------------
// Mapping helpers
// ---------------------------------------------------------------------------

interface RawErrorBody {
  message?: unknown;
  messageKey?: unknown;
  detail?: unknown;
  error?: unknown;
  code?: unknown;
  params?: unknown;
  request_id?: unknown;
  requestId?: unknown;
}

function pickString(...candidates: unknown[]): string | undefined {
  for (const c of candidates) {
    if (typeof c === "string" && c.length > 0) return c;
  }
  return undefined;
}

function pickNumber(...candidates: unknown[]): number | undefined {
  for (const c of candidates) {
    if (typeof c === "number" && Number.isFinite(c)) return c;
  }
  return undefined;
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === "object";
}

/**
 * Convert an HTTP status + parsed body into a typed SDK error.
 *
 * The body may already be camel-cased (we are downstream of the response
 * transform). To stay defensive we still accept the raw snake_case fields.
 */
export function mapHttpErrorBody(args: {
  status: number;
  body: unknown;
  url: string;
  method: string;
  headers?: Headers | Record<string, string>;
}): TeamverApiError {
  const { status, body, headers } = args;

  const raw: RawErrorBody = isRecord(body) ? (body as RawErrorBody) : {};
  const messageKey = pickString(raw.message, raw.messageKey);
  const code = pickString(raw.code, raw.error);
  const requestId = pickString(
    raw.requestId,
    raw.request_id,
    typeof headers === "object" && headers && "get" in headers
      ? (headers as Headers).get("x-request-id") ?? undefined
      : (headers as Record<string, string> | undefined)?.["x-request-id"],
  );
  const detail = isRecord(raw.detail) ? (raw.detail as Record<string, unknown>) : undefined;
  const detailString = typeof raw.detail === "string" ? raw.detail : undefined;
  const message = messageKey ?? detailString ?? code ?? `HTTP ${status}`;
  const params = isRecord(raw.params) ? (raw.params as Record<string, unknown>) : undefined;

  const baseInit: TeamverApiErrorInit = {
    status,
    code,
    messageKey,
    message,
    params,
    requestId,
    responseBody: body,
  };

  // Login provider mismatch: BE returns `error.login_provider.not_valid.<PROVIDER>`.
  if (
    status === 400 &&
    typeof messageKey === "string" &&
    messageKey.startsWith("error.login_provider.not_valid")
  ) {
    const expectedFromKey = messageKey.split(".").pop();
    return new LoginProviderMismatchError({
      ...baseInit,
      expectedLoginProvider:
        (params?.expectedLoginProvider as string | undefined) ?? expectedFromKey,
      oauthCallbackPath: (params?.oauthCallbackPath as string | null | undefined) ?? null,
      emailLoginPath: (params?.emailLoginPath as string | null | undefined) ?? null,
      organizationEmailLoginPath:
        (params?.organizationEmailLoginPath as string | null | undefined) ?? null,
    });
  }

  // Quota exceeded: 403 + { error: "QUOTA_EXCEEDED", detail: { quota_type, ... } }
  if (status === 403 && code === "QUOTA_EXCEEDED") {
    return new QuotaExceededError({
      ...baseInit,
      quotaType: pickString(detail?.quotaType, detail?.quota_type),
      limit: pickNumber(detail?.limit),
      current: pickNumber(detail?.current),
      planName: pickString(detail?.planName, detail?.plan_name),
      upgradeUrl: pickString(detail?.upgradeUrl, detail?.upgrade_url),
    });
  }

  if (status === 401) return new AuthenticationError(baseInit);
  if (status === 403) return new ForbiddenError(baseInit);
  if (status === 404) return new NotFoundError(baseInit);
  if (status === 429) {
    const retryAfter =
      typeof headers === "object" && headers && "get" in headers
        ? (headers as Headers).get("retry-after")
        : (headers as Record<string, string> | undefined)?.["retry-after"];
    const retryAfterMs =
      typeof retryAfter === "string" && /^\d+$/.test(retryAfter)
        ? Number(retryAfter) * 1000
        : undefined;
    return new RateLimitError({ ...baseInit, retryAfterMs });
  }
  if (status >= 500) return new MainBEUnavailableError(baseInit);
  if (status >= 400) return new ValidationError(baseInit);

  return new TeamverApiError(baseInit);
}
