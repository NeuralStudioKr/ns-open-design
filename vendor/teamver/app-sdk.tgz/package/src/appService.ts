import type { TeamverHttpClient } from "./http";
import type {
  AppServiceContextVerifyInput,
  AppServiceContextVerifyResponse,
  AppServiceHeartbeatInput,
  AppServiceHeartbeatResponse,
  AppServiceRegistryCredentials,
  AppServiceUsageReportInput,
  AppServiceUsageReportResponse,
  AppServiceEventInput,
  AppServiceEventResponse,
  RequestOptions,
} from "./types";

function registryHeaders(credentials: AppServiceRegistryCredentials): Record<string, string> {
  return {
    "X-Teamver-App-Id": credentials.appId,
    "X-Teamver-Key-Id": credentials.keyId,
    "X-Teamver-Access-Key": credentials.accessKey,
  };
}

/**
 * `/api/app-service/*` — AI App Registry 런타임 (docs/116 §9).
 *
 * - `verifyContext`: user JWT + Registry key + workspace (Slide BE user 요청 전).
 * - `heartbeat`: Registry key only (App BE → Main BE health).
 * - `usageReport`: Registry key only (App BE → Main BE usage, 116 §9.4).
 * - `postEvent`: Registry key — `/app-service/events` or pass `audit: true` for `/audit/events`.
 */
export class AppServiceClient {
  constructor(private readonly http: TeamverHttpClient) {}

  async verifyContext(
    input: AppServiceContextVerifyInput,
    options: RequestOptions = {},
  ): Promise<AppServiceContextVerifyResponse> {
    const creds = input.credentials;
    return this.http.post<AppServiceContextVerifyResponse>(
      "/app-service/context/verify",
      {
        workspaceId: input.workspaceId,
        appId: input.appId,
      },
      {
        workspaceId: input.workspaceId,
        headers: {
          ...registryHeaders(creds),
          ...options.headers,
        },
        ...options,
      },
    );
  }

  async heartbeat(
    appId: string,
    payload: AppServiceHeartbeatInput,
    credentials: AppServiceRegistryCredentials,
    options: RequestOptions = {},
  ): Promise<AppServiceHeartbeatResponse> {
    return this.http.post<AppServiceHeartbeatResponse>(
      `/app-service/apps/${encodeURIComponent(appId)}/heartbeat`,
      payload,
      {
        skipAuthHeader: true,
        skipWorkspaceIdHeader: true,
        headers: {
          ...registryHeaders(credentials),
          ...options.headers,
        },
        ...options,
      },
    );
  }

  async usageReport(
    appId: string,
    payload: AppServiceUsageReportInput,
    credentials: AppServiceRegistryCredentials,
    options: RequestOptions = {},
  ): Promise<AppServiceUsageReportResponse> {
    return this.http.post<AppServiceUsageReportResponse>(
      `/app-service/apps/${encodeURIComponent(appId)}/usage-report`,
      {
        workspaceId: payload.workspaceId,
        userId: payload.userId,
        usageType: payload.usageType,
        quantity: payload.quantity,
        unit: payload.unit,
        metadata: payload.metadata,
      },
      {
        skipAuthHeader: true,
        skipWorkspaceIdHeader: true,
        headers: {
          ...registryHeaders(credentials),
          ...options.headers,
        },
        ...options,
      },
    );
  }

  async postEvent(
    payload: AppServiceEventInput,
    credentials: AppServiceRegistryCredentials,
    options: RequestOptions & { audit?: boolean } = {},
  ): Promise<AppServiceEventResponse> {
    const path = options.audit ? "/audit/events" : "/app-service/events";
    const { audit: _audit, ...rest } = options;
    return this.http.post<AppServiceEventResponse>(
      path,
      {
        workspaceId: payload.workspaceId,
        eventType: payload.eventType,
        appId: payload.appId,
        userId: payload.userId,
        metadata: payload.metadata,
      },
      {
        skipAuthHeader: true,
        skipWorkspaceIdHeader: true,
        headers: {
          ...registryHeaders(credentials),
          ...rest.headers,
        },
        ...rest,
      },
    );
  }
}
