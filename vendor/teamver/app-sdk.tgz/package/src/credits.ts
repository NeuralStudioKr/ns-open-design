import type { TeamverHttpClient } from "./http";
import type {
  CreditBalanceResponse,
  CreditConfirmInput,
  CreditConfirmResponse,
  CreditOrderIssueResponse,
  CreditOrderListResponse,
  CreditOrdersParams,
  CreditPack,
  RequestOptions,
  SendEligibilityParams,
  SendEligibilityResponse,
} from "./types";

function normalizePacks(raw: unknown): CreditPack[] {
  if (Array.isArray(raw)) return raw as CreditPack[];
  if (raw && typeof raw === "object") {
    const r = raw as Record<string, unknown>;
    if (Array.isArray(r.packs)) return r.packs as CreditPack[];
    if (Array.isArray(r.items)) return r.items as CreditPack[];
  }
  return [];
}

function normalizeOrders(raw: unknown): CreditOrderListResponse {
  if (Array.isArray(raw)) return { orders: raw as CreditOrderListResponse["orders"] };
  if (raw && typeof raw === "object") {
    const r = raw as Record<string, unknown>;
    if (Array.isArray(r.orders)) return raw as CreditOrderListResponse;
    if (Array.isArray(r.items)) return { ...r, orders: r.items as CreditOrderListResponse["orders"] };
  }
  return { orders: [] };
}

/** `/api/credits/*` wrapper. */
export class CreditsClient {
  constructor(private readonly http: TeamverHttpClient) {}

  async balance(options: RequestOptions = {}): Promise<CreditBalanceResponse> {
    return this.http.get<CreditBalanceResponse>("/credits/balance", options);
  }

  async sendEligibility(
    params: SendEligibilityParams,
    options: RequestOptions = {},
  ): Promise<SendEligibilityResponse> {
    return this.http.get<SendEligibilityResponse>("/credits/send-eligibility", {
      query: params as Record<string, unknown>,
      ...options,
    });
  }

  async packs(options: RequestOptions = {}): Promise<CreditPack[]> {
    const raw = await this.http.get<unknown>("/credits/packs", options);
    return normalizePacks(raw);
  }

  async orders(
    params: CreditOrdersParams = {},
    options: RequestOptions = {},
  ): Promise<CreditOrderListResponse> {
    const raw = await this.http.get<unknown>("/credits/orders", {
      query: params as Record<string, unknown>,
      ...options,
    });
    return normalizeOrders(raw);
  }

  async createOrder(
    creditPackId: string,
    options: RequestOptions = {},
  ): Promise<CreditOrderIssueResponse> {
    return this.http.post<CreditOrderIssueResponse>(
      "/credits/orders",
      { creditPackId },
      options,
    );
  }

  async confirmPayment(
    input: CreditConfirmInput,
    options: RequestOptions = {},
  ): Promise<CreditConfirmResponse> {
    return this.http.post<CreditConfirmResponse>("/credits/confirm", input, options);
  }
}
