/**
 * Public type surface of `@teamver/app-sdk`.
 *
 * - Public types use camelCase. Raw BE payloads stay internal.
 * - Enums fall back to plain `string` to avoid over-tightening contracts.
 * - Optional fields use `| null | undefined` only when the BE genuinely sends null.
 */

// ---------------------------------------------------------------------------
// Request / response options
// ---------------------------------------------------------------------------

export type HttpMethod = "GET" | "POST" | "PATCH" | "PUT" | "DELETE";

/** Common per-request overrides used across every wrapper. */
export interface RequestOptions {
  /** Explicit `X-Workspace-Id` for this request. Wins over store/header. */
  workspaceId?: string | null;
  /** Skip injecting `X-Workspace-Id` entirely (e.g. `/user/me`). */
  skipWorkspaceIdHeader?: boolean;
  /** Skip the bearer-token auth header (e.g. `/auth/login`, S3 PUT). */
  skipAuthHeader?: boolean;
  /** Skip the snake_case → camelCase response transform (binary). */
  skipResponseTransform?: boolean;
  /** Skip the camelCase → snake_case body transform. */
  skipRequestTransform?: boolean;
  /** Skip the 401 → refresh recovery for this single call. */
  skipAuthRecovery?: boolean;
  /** Caller-supplied AbortSignal. */
  signal?: AbortSignal;
  /** Per-request timeout override (ms). Default comes from client config. */
  timeoutMs?: number;
  /** Extra headers merged on top of the auto-injected ones. */
  headers?: Record<string, string>;
  /** Query string parameters. Keys are camelCase, sent as snake_case. */
  query?: Record<string, unknown>;
  /** Shared drive scope — sets `shared_drive_id` body + `X-Shared-Drive-Id`. */
  sharedDriveId?: string | null;
}

// ---------------------------------------------------------------------------
// Client config
// ---------------------------------------------------------------------------

/** Abstraction over access-token storage (localStorage, cookie, in-memory). */
export interface TokenStore {
  get(): string | null | Promise<string | null>;
  set(token: string | null): void | Promise<void>;
}

/** Abstraction over the active workspace id selection. */
export interface WorkspaceStore {
  get(): string | null | Promise<string | null>;
  set(workspaceId: string | null): void | Promise<void>;
}

export interface TeamverClientConfig {
  /** Raw API base URL; will be normalised (root → `/api`). */
  apiBaseUrl?: string;
  /**
   * Optional absolute refresh endpoint (cookie SSO).
   * When set, 401 recovery POSTs here instead of `{apiBaseUrl}/auth/refresh`.
   * Embed apps should point at Main BE `/api/auth/refresh`.
   */
  refreshUrl?: string;
  /** AI App identifier — informational; FE SDK does not call `/internal/*`. */
  appKey?: string;
  /** Optional access-token store. If omitted, SDK relies purely on cookies. */
  tokenStore?: TokenStore | null;
  /** Optional active-workspace store. */
  workspaceStore?: WorkspaceStore | null;
  /** Default request timeout (ms). Defaults to 30 000. */
  requestTimeoutMs?: number;
  /** Send `credentials: "include"`. Defaults to true. */
  withCredentials?: boolean;
  /** Custom `fetch` (testing, polyfill, server-side rendering). */
  fetch?: typeof fetch;
  /**
   * Called once the refresh attempt fails (after a 401 retry).
   * Hosts should redirect to login / clear local state.
   */
  onAuthExpired?: () => void | Promise<void>;
  /** Hook for observability — request lifecycle events. */
  onRequest?: (info: { method: HttpMethod; url: string }) => void;
  onResponse?: (info: { method: HttpMethod; url: string; status: number }) => void;
}

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------

export interface LoginResponse {
  accessToken?: string | null;
  user?: User | null;
  /** Pass-through additional fields from main BE. */
  [k: string]: unknown;
}

export interface LogoutResponse {
  success?: boolean;
  message?: string;
  logoutRedirectUri?: string | null;
  [k: string]: unknown;
}

// ---------------------------------------------------------------------------
// User
// ---------------------------------------------------------------------------

export interface User {
  id: string;
  email: string;
  name?: string | null;
  role?: string | null;
  personalWorkspaceId?: string | null;
  imagePath?: string | null;
  s3ImageUrl?: string | null;
  [k: string]: unknown;
}

export interface UpdateUserPayload {
  name?: string;
  imagePath?: string | null;
  [k: string]: unknown;
}

// ---------------------------------------------------------------------------
// Workspace
// ---------------------------------------------------------------------------

export type WorkspaceRole = "owner" | "admin" | "member" | string;
export type WorkspaceKind = "personal" | "team" | string;

export interface WorkspaceListItem {
  id: string;
  name: string;
  workspaceKind?: WorkspaceKind;
  role: WorkspaceRole;
  isAccountDefaultWorkspace?: boolean;
  code?: string | null;
  s3ImageUrl?: string | null;
  [k: string]: unknown;
}

export interface WorkspaceListResponse {
  workspaces: WorkspaceListItem[];
  [k: string]: unknown;
}

export interface TeamWorkspace extends WorkspaceListItem {}

export interface CreateWorkspaceResponse {
  id: string;
  name?: string;
  [k: string]: unknown;
}

export interface UpdateWorkspacePayload {
  name?: string;
  imagePath?: string | null;
  [k: string]: unknown;
}

export interface WorkspaceMembersOverviewResponse {
  totalMembers?: number;
  members?: User[];
  [k: string]: unknown;
}

// ---------------------------------------------------------------------------
// Drive
// ---------------------------------------------------------------------------

export type DriveAssetKind = "uploaded" | "ai_generated" | string;
export type DriveUploadStatus = "ready" | "processing" | "failed" | string;

export interface DriveAssetItem {
  assetId: string;
  name: string;
  kind?: DriveAssetKind | null;
  type?: string | null;
  folderId?: string | null;
  sharedDriveId?: string | null;
  uploadStatus?: DriveUploadStatus | null;
  sizeBytes?: number | null;
  createdAt?: string | null;
  updatedAt?: string | null;
  [k: string]: unknown;
}

export interface DriveFolderItem {
  folderId: string;
  name: string;
  parentFolderId?: string | null;
  sharedDriveId?: string | null;
  [k: string]: unknown;
}

export interface DriveListItem {
  itemType: "folder" | "asset" | string;
  folder?: DriveFolderItem;
  asset?: DriveAssetItem;
  [k: string]: unknown;
}

export interface CursorPaginatedResponse<T> {
  items: T[];
  nextCursor?: string | null;
  hasMore?: boolean;
  [k: string]: unknown;
}

export interface DriveListParams {
  folderId?: string | null;
  sharedDriveId?: string | null;
  cursor?: string | null;
  limit?: number;
  search?: string;
  kind?: string;
  sort?: string;
  [k: string]: unknown;
}

export interface DriveFolderTreeParams {
  sharedDriveId?: string | null;
  [k: string]: unknown;
}

export interface DriveFolderTreeNode {
  folderId: string;
  name: string;
  children?: DriveFolderTreeNode[];
  [k: string]: unknown;
}

export interface DriveFolderTreeResponse {
  tree: DriveFolderTreeNode[];
  [k: string]: unknown;
}

export interface DriveHomeSearchParams {
  q: string;
  sharedDriveId?: string | null;
  limit?: number;
  cursor?: string | null;
}

export interface DriveHomeSearchResponse {
  items: DriveAssetItem[];
  nextCursor?: string | null;
  [k: string]: unknown;
}

export interface DriveHomeRecentParams {
  sharedDriveId?: string | null;
  limit?: number;
}

export interface DriveHomeRecentResponse {
  items: DriveAssetItem[];
  [k: string]: unknown;
}

export interface DriveDownloadParams {
  sharedDriveId?: string | null;
}

export interface DriveDownloadUrlResponse {
  downloadUrl: string;
  filename?: string | null;
  expiresAt?: string | null;
  [k: string]: unknown;
}

export interface DriveUploadRequestInput {
  filename: string;
  contentType: string;
  sizeBytes: number;
  folderId?: string | null;
  sharedDriveId?: string | null;
  kind?: DriveAssetKind | null;
  [k: string]: unknown;
}

export interface DriveUploadTicket {
  assetId: string;
  presignedUrl: string;
  headers?: Record<string, string>;
  method?: "PUT" | string;
  expiresAt?: string | null;
  [k: string]: unknown;
}

export interface DriveUploadConfirmResponse {
  asset?: DriveAssetItem;
  alreadyConfirmed?: boolean;
  [k: string]: unknown;
}

export interface DriveUploadFileInput {
  folderId?: string | null;
  sharedDriveId?: string | null;
  kind?: DriveAssetKind | null;
  contentType?: string;
  filename?: string;
  /** Optional progress callback (0..1). May be indeterminate in fetch mode. */
  onProgress?: (progress: number) => void;
  /** Skip presigned PUT (test/mock). */
  presignedPutAdapter?: (ticket: DriveUploadTicket, file: Blob) => Promise<void>;
}

export interface DriveSharingParams {
  sharedDriveId?: string | null;
}

export interface AssetSharingOverviewResponse {
  assetId: string;
  ownerId?: string | null;
  visibility?: string | null;
  sharedWith?: Array<{ userId: string; role?: string | null }>;
  [k: string]: unknown;
}

// ---------------------------------------------------------------------------
// Shared drive
// ---------------------------------------------------------------------------

export interface SharedDrive {
  id: string;
  name: string;
  workspaceId?: string | null;
  ownerId?: string | null;
  archivedAt?: string | null;
  [k: string]: unknown;
}

export interface SharedDriveListParams {
  includeArchived?: boolean;
}

export interface SharedDriveCreateInput {
  name: string;
  workspaceId?: string | null;
  [k: string]: unknown;
}

export interface SharedDriveUpdateInput {
  name?: string;
  [k: string]: unknown;
}

export interface SharedDriveAccessCheckResponse {
  hasAccess: boolean;
  role?: string | null;
  [k: string]: unknown;
}

// ---------------------------------------------------------------------------
// Billing / Credits / Subscription
// ---------------------------------------------------------------------------

export interface CreditBalanceResponse {
  workspaceId?: string | null;
  balance: number;
  currency?: string | null;
  [k: string]: unknown;
}

export interface SendEligibilityParams {
  toUserId?: string;
  toEmail?: string;
  amount?: number;
}

export interface SendEligibilityResponse {
  eligible: boolean;
  reason?: string | null;
  [k: string]: unknown;
}

export interface CreditPack {
  id: string;
  name: string;
  credits: number;
  priceCents: number;
  currency?: string | null;
  [k: string]: unknown;
}

export interface CreditOrdersParams {
  cursor?: string | null;
  limit?: number;
  status?: string;
}

export interface CreditOrderListResponse {
  orders: CreditOrder[];
  nextCursor?: string | null;
  [k: string]: unknown;
}

export interface CreditOrder {
  id: string;
  creditPackId: string;
  status: string;
  amountCents?: number;
  currency?: string | null;
  createdAt?: string | null;
  [k: string]: unknown;
}

export interface CreditOrderIssueResponse {
  orderId: string;
  paymentUrl?: string | null;
  paymentToken?: string | null;
  [k: string]: unknown;
}

export interface CreditConfirmInput {
  orderId: string;
  paymentKey?: string;
  amount?: number;
  [k: string]: unknown;
}

export interface CreditConfirmResponse {
  orderId: string;
  status: string;
  balanceAfter?: number;
  [k: string]: unknown;
}

export interface BillingCheckoutInput {
  planId: string;
  billingCycle?: string;
  successUrl?: string;
  cancelUrl?: string;
  [k: string]: unknown;
}

export interface BillingCheckoutResponse {
  checkoutUrl?: string | null;
  sessionId?: string | null;
  [k: string]: unknown;
}

export interface RegisterBillingCallbackInput {
  authKey: string;
  customerKey?: string;
  [k: string]: unknown;
}

export interface ReplaceCardInput {
  authKey: string;
  customerKey?: string;
  [k: string]: unknown;
}

export interface ReplaceCardResponse {
  success?: boolean;
  message?: string;
  [k: string]: unknown;
}

export interface SubscriptionMeResponse {
  workspaceId?: string | null;
  planId?: string | null;
  planName?: string | null;
  status?: string | null;
  billingCycle?: string | null;
  cancelAtPeriodEnd?: boolean;
  currentPeriodEnd?: string | null;
  [k: string]: unknown;
}

// ---------------------------------------------------------------------------
// App service (Registry runtime, /api/app-service/*)
// ---------------------------------------------------------------------------

export interface AppServiceRegistryCredentials {
  appId: string;
  keyId: string;
  accessKey: string;
}

export interface AppServiceContextVerifyInput {
  workspaceId: string;
  appId: string;
  credentials: AppServiceRegistryCredentials;
}

export interface AppServiceContextVerifyResponse {
  userId: string;
  workspaceId: string;
  role: string;
  appId: string;
  permissions: string[];
}

export interface AppServiceHeartbeatInput {
  status: string;
  version?: string;
  metadata?: Record<string, unknown>;
}

export interface AppServiceHeartbeatResponse {
  appId: string;
  status: string;
  receivedAt: string;
}

export interface AppServiceUsageReportInput {
  workspaceId: string;
  userId: string;
  usageType: string;
  quantity?: number;
  unit?: string;
  metadata?: Record<string, unknown>;
}

export interface AppServiceUsageReportResponse {
  appId: string;
  status: string;
  receivedAt: string;
}

export interface AppServiceEventInput {
  workspaceId: string;
  eventType: string;
  appId?: string;
  userId?: string;
  metadata?: Record<string, unknown>;
}

export interface AppServiceEventResponse {
  appId: string;
  status: string;
  receivedAt: string;
  eventId: string;
}

export interface RegistryBillingReserveInput {
  workspaceId: string;
  appId?: string;
  amount: number;
  reason?: string;
}

export interface RegistryBillingReserveResponse {
  usageId: string;
}

export interface RegistryBillingCommitInput {
  usageId: string;
}

export interface RegistryBillingCommitResponse {
  usageId: string;
  status: string;
}

export interface RegistryBillingRefundInput {
  usageId: string;
  reason?: string;
}

export interface RegistryBillingRefundResponse {
  usageId: string;
  status: string;
}

// ---------------------------------------------------------------------------
// Back-compat (do not break existing import)
// ---------------------------------------------------------------------------

/** @deprecated Use `TeamverClientConfig`. Kept for backward compat. */
export type TeamverAppConfig = TeamverClientConfig;
