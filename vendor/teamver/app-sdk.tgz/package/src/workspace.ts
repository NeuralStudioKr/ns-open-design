import type { TeamverHttpClient } from "./http";
import type {
  CreateWorkspaceResponse,
  RequestOptions,
  TeamWorkspace,
  UpdateWorkspacePayload,
  User,
  WorkspaceListResponse,
  WorkspaceMembersOverviewResponse,
} from "./types";

function normalizeWorkspaceListResponse(raw: unknown): WorkspaceListResponse {
  if (Array.isArray(raw)) return { workspaces: raw as WorkspaceListResponse["workspaces"] };
  if (raw && typeof raw === "object") {
    const r = raw as Record<string, unknown>;
    if (Array.isArray(r.workspaces)) return raw as WorkspaceListResponse;
    if (Array.isArray(r.items)) return { ...r, workspaces: r.items as WorkspaceListResponse["workspaces"] };
    if (Array.isArray(r.data)) return { ...r, workspaces: r.data as WorkspaceListResponse["workspaces"] };
  }
  return { workspaces: [] };
}

/**
 * `/api/v2/workspace/*` wrapper.
 *
 * - `listMine()` / `listForSettings()` skip workspace header (they describe the
 *   set of available workspaces — header would be meaningless).
 * - Per-workspace endpoints accept a `workspaceId` request override so callers
 *   can always be explicit even if the store has a different active id.
 */
export class WorkspaceClient {
  constructor(private readonly http: TeamverHttpClient) {}

  async listMine(options: RequestOptions = {}): Promise<WorkspaceListResponse> {
    const raw = await this.http.get<unknown>("/v2/workspace/me", {
      skipWorkspaceIdHeader: true,
      ...options,
    });
    return normalizeWorkspaceListResponse(raw);
  }

  async listForSettings(options: RequestOptions = {}): Promise<WorkspaceListResponse> {
    const raw = await this.http.get<unknown>("/v2/workspace/settings/list", {
      skipWorkspaceIdHeader: true,
      ...options,
    });
    return normalizeWorkspaceListResponse(raw);
  }

  async get(workspaceId: string, options: RequestOptions = {}): Promise<TeamWorkspace> {
    return this.http.get<TeamWorkspace>(`/v2/workspace/${encodeURIComponent(workspaceId)}`, {
      workspaceId,
      ...options,
    });
  }

  async create(
    payload: FormData | Record<string, unknown>,
    options: RequestOptions = {},
  ): Promise<CreateWorkspaceResponse> {
    return this.http.post<CreateWorkspaceResponse>("/v2/workspace", payload, {
      skipWorkspaceIdHeader: true,
      ...options,
    });
  }

  async update(
    workspaceId: string,
    payload: FormData | UpdateWorkspacePayload,
    options: RequestOptions = {},
  ): Promise<TeamWorkspace> {
    return this.http.patch<TeamWorkspace>(
      `/v2/workspace/${encodeURIComponent(workspaceId)}`,
      payload,
      { workspaceId, ...options },
    );
  }

  async leave(
    workspaceId: string,
    params: { delegateToUserId?: string } = {},
    options: RequestOptions = {},
  ): Promise<void> {
    await this.http.post<unknown>(
      `/v2/workspace/${encodeURIComponent(workspaceId)}/leave`,
      params,
      { workspaceId, ...options },
    );
  }

  async membersOverview(
    workspaceId: string,
    options: RequestOptions = {},
  ): Promise<WorkspaceMembersOverviewResponse> {
    return this.http.get<WorkspaceMembersOverviewResponse>(
      `/v2/workspace/${encodeURIComponent(workspaceId)}/members-overview`,
      { workspaceId, ...options },
    );
  }

  async memberRoster(workspaceId: string, options: RequestOptions = {}): Promise<User[]> {
    const raw = await this.http.get<unknown>(
      `/v2/workspace/${encodeURIComponent(workspaceId)}/member-roster`,
      { workspaceId, ...options },
    );
    if (Array.isArray(raw)) return raw as User[];
    if (raw && typeof raw === "object") {
      const r = raw as Record<string, unknown>;
      if (Array.isArray(r.members)) return r.members as User[];
      if (Array.isArray(r.users)) return r.users as User[];
      if (Array.isArray(r.items)) return r.items as User[];
    }
    return [];
  }

  async admins(workspaceId: string, options: RequestOptions = {}): Promise<User[]> {
    const raw = await this.http.get<unknown>(
      `/v2/workspace/${encodeURIComponent(workspaceId)}/admins`,
      { workspaceId, ...options },
    );
    if (Array.isArray(raw)) return raw as User[];
    if (raw && typeof raw === "object") {
      const r = raw as Record<string, unknown>;
      if (Array.isArray(r.admins)) return r.admins as User[];
      if (Array.isArray(r.users)) return r.users as User[];
    }
    return [];
  }
}
