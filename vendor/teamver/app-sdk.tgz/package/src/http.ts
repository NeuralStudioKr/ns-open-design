import {
  buildSnakeSearchParams,
  camelToSnakeDeep,
  snakeCaseFormData,
  snakeToCamelDeep,
} from "./casing";
import { NetworkError, mapHttpErrorBody } from "./errors";
import type {
  HttpMethod,
  RequestOptions,
  TeamverClientConfig,
  TokenStore,
  WorkspaceStore,
} from "./types";

/** Default API base URL — matches the spec. */
export const DEFAULT_API_BASE_URL = "https://api.teamver.com/api";

/** Default request timeout (ms). Matches `ns-teamver-fe-v2/web/src/lib/api.ts`. */
export const DEFAULT_REQUEST_TIMEOUT_MS = 30_000;

const AUTH_REFRESH_PATH = "/auth/refresh";

/**
 * Normalise an API base URL so it always ends with `/api` when the caller
 * passed only the host root.
 *
 * | input                          | output                          |
 * | ------------------------------ | ------------------------------- |
 * | https://api.teamver.com        | https://api.teamver.com/api     |
 * | https://api.teamver.com/api    | https://api.teamver.com/api     |
 * | http://localhost:8000          | http://localhost:8000/api       |
 * | /be-api                        | /be-api                         |
 * | /be-api/                       | /be-api                         |
 */
export function normalizeApiBaseUrl(raw: string | undefined | null): string {
  const fallback = DEFAULT_API_BASE_URL;
  if (!raw || typeof raw !== "string") return fallback;
  const trimmed = raw.trim().replace(/\/+$/, "");
  if (!trimmed) return fallback;

  if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
    try {
      const parsed = new URL(trimmed);
      const pathname = parsed.pathname.replace(/\/+$/, "");
      if (pathname === "" || pathname === "/") {
        return `${parsed.origin}/api`;
      }
      return `${parsed.origin}${pathname}`;
    } catch {
      return trimmed;
    }
  }

  // Relative URL (e.g. Next.js proxy `/be-api`).
  if (trimmed.startsWith("/")) return trimmed;
  return `/${trimmed}`;
}

function sanitizePath(path: string): string {
  if (!path) return "/";
  return path.startsWith("/") ? path : `/${path}`;
}

function joinBaseAndPath(base: string, path: string): string {
  const safePath = sanitizePath(path);
  if (base.startsWith("http://") || base.startsWith("https://")) {
    return `${base}${safePath}`;
  }
  return `${base}${safePath}`;
}

function isBinaryBody(body: unknown): boolean {
  return (
    (typeof FormData !== "undefined" && body instanceof FormData) ||
    (typeof Blob !== "undefined" && body instanceof Blob) ||
    (typeof ArrayBuffer !== "undefined" && body instanceof ArrayBuffer) ||
    (typeof URLSearchParams !== "undefined" && body instanceof URLSearchParams) ||
    (typeof ReadableStream !== "undefined" && body instanceof ReadableStream)
  );
}

async function maybeResolve<T>(v: T | Promise<T>): Promise<T> {
  return v instanceof Promise ? await v : v;
}

function combineSignals(parent: AbortSignal | undefined, timeoutMs: number): {
  signal: AbortSignal;
  cleanup: () => void;
} {
  const controller = new AbortController();
  const cleanups: Array<() => void> = [];

  const timer = setTimeout(() => controller.abort(new DOMException("Timeout", "TimeoutError")), timeoutMs);
  cleanups.push(() => clearTimeout(timer));

  if (parent) {
    if (parent.aborted) {
      controller.abort(parent.reason);
    } else {
      const onAbort = () => controller.abort(parent.reason);
      parent.addEventListener("abort", onAbort, { once: true });
      cleanups.push(() => parent.removeEventListener("abort", onAbort));
    }
  }

  return {
    signal: controller.signal,
    cleanup: () => cleanups.forEach((fn) => fn()),
  };
}

export interface HttpClientInternals {
  readonly apiBaseUrl: string;
  readonly tokenStore: TokenStore | null;
  readonly workspaceStore: WorkspaceStore | null;
  /** Forces the refresh logic to use a brand new promise next time. */
  resetRefreshState(): void;
}

/**
 * Low-level HTTP client used by every domain wrapper.
 *
 * Responsibilities:
 *  - URL composition + query encoding (snake_case)
 *  - JSON / FormData body encoding (camel → snake)
 *  - Authorization + X-Workspace-Id + X-Shared-Drive-Id headers
 *  - timeout + abort signal composition
 *  - 401 → /auth/refresh → retry-once recovery
 *  - HTTP error → typed SDK error mapping
 *  - response body decoding (snake → camel) for JSON, pass-through for binary
 */
export class TeamverHttpClient implements HttpClientInternals {
  readonly apiBaseUrl: string;
  readonly tokenStore: TokenStore | null;
  readonly workspaceStore: WorkspaceStore | null;

  private readonly defaultTimeoutMs: number;
  private readonly withCredentials: boolean;
  /** Exposed so non-API helpers (e.g. S3 PUT) can share the same fetch in tests. */
  readonly fetchImpl: typeof fetch;
  private readonly onAuthExpired?: () => void | Promise<void>;
  private readonly onRequest?: TeamverClientConfig["onRequest"];
  private readonly onResponse?: TeamverClientConfig["onResponse"];
  private readonly refreshUrl: string | null;

  private inflightRefresh: Promise<string | null> | null = null;

  constructor(config: TeamverClientConfig) {
    this.apiBaseUrl = normalizeApiBaseUrl(config.apiBaseUrl);
    this.refreshUrl = config.refreshUrl?.trim() || null;
    this.tokenStore = config.tokenStore ?? null;
    this.workspaceStore = config.workspaceStore ?? null;
    this.defaultTimeoutMs = config.requestTimeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
    this.withCredentials = config.withCredentials ?? true;
    const baseFetch = config.fetch ?? (typeof fetch !== "undefined" ? fetch : undefined);
    if (!baseFetch) {
      throw new Error(
        "TeamverHttpClient: no `fetch` available. Provide `config.fetch` (e.g. cross-fetch) for non-browser runtimes.",
      );
    }
    // Bind globally-defined fetch to avoid `Illegal invocation` errors.
    this.fetchImpl = baseFetch.bind(globalThis);
    this.onAuthExpired = config.onAuthExpired;
    this.onRequest = config.onRequest;
    this.onResponse = config.onResponse;
  }

  resetRefreshState(): void {
    this.inflightRefresh = null;
  }

  // --- Verb helpers -------------------------------------------------------

  get<T = unknown>(path: string, options?: RequestOptions): Promise<T> {
    return this.request<T>("GET", path, undefined, options);
  }

  post<T = unknown>(path: string, body?: unknown, options?: RequestOptions): Promise<T> {
    return this.request<T>("POST", path, body, options);
  }

  patch<T = unknown>(path: string, body?: unknown, options?: RequestOptions): Promise<T> {
    return this.request<T>("PATCH", path, body, options);
  }

  put<T = unknown>(path: string, body?: unknown, options?: RequestOptions): Promise<T> {
    return this.request<T>("PUT", path, body, options);
  }

  delete<T = unknown>(path: string, options?: RequestOptions): Promise<T> {
    return this.request<T>("DELETE", path, undefined, options);
  }

  // --- Core ---------------------------------------------------------------

  async request<T = unknown>(
    method: HttpMethod,
    path: string,
    body?: unknown,
    options: RequestOptions = {},
  ): Promise<T> {
    return this.executeWithRecovery<T>(method, path, body, options, /* hasRetried */ false);
  }

  private async executeWithRecovery<T>(
    method: HttpMethod,
    path: string,
    body: unknown,
    options: RequestOptions,
    hasRetried: boolean,
  ): Promise<T> {
    const { url, init } = await this.buildRequest(method, path, body, options);
    const timeoutMs = options.timeoutMs ?? this.defaultTimeoutMs;
    const { signal, cleanup } = combineSignals(options.signal, timeoutMs);

    this.onRequest?.({ method, url });
    let response: Response;
    try {
      response = await this.fetchImpl(url, { ...init, signal });
    } catch (err) {
      cleanup();
      if (err instanceof DOMException && err.name === "AbortError") {
        // Could be timeout or caller abort.
        const isTimeout = !options.signal?.aborted;
        throw new NetworkError({
          status: 0,
          message: isTimeout ? "Request timed out" : "Request aborted",
          code: isTimeout ? "TIMEOUT" : "ABORTED",
          cause: err,
        });
      }
      throw new NetworkError({
        status: 0,
        message: err instanceof Error ? err.message : "Network error",
        code: "NETWORK",
        cause: err,
      });
    }
    cleanup();
    this.onResponse?.({ method, url, status: response.status });

    if (response.status === 401 && !hasRetried && !options.skipAuthRecovery && !isAuthPath(path)) {
      const newToken = await this.tryRefreshToken();
      if (newToken) {
        return this.executeWithRecovery<T>(method, path, body, options, true);
      }
      const failedBody = await this.parseResponseBody(response, options).catch(() => undefined);
      const err = mapHttpErrorBody({
        status: response.status,
        body: failedBody,
        url,
        method,
        headers: response.headers,
      });
      if (this.onAuthExpired) {
        try {
          await this.onAuthExpired();
        } catch {
          // never let the consumer hook propagate
        }
      }
      throw err;
    }

    if (!response.ok) {
      const errBody = await this.parseResponseBody(response, options);
      throw mapHttpErrorBody({
        status: response.status,
        body: errBody,
        url,
        method,
        headers: response.headers,
      });
    }

    return (await this.parseResponseBody(response, options)) as T;
  }

  // --- Refresh logic ------------------------------------------------------

  private async tryRefreshToken(): Promise<string | null> {
    if (!this.inflightRefresh) {
      this.inflightRefresh = this.runRefresh().finally(() => {
        // Allow next 401 to trigger a fresh refresh.
        this.inflightRefresh = null;
      });
    }
    try {
      return await this.inflightRefresh;
    } catch {
      return null;
    }
  }

  private async runRefresh(): Promise<string | null> {
    const url = this.refreshUrl ?? joinBaseAndPath(this.apiBaseUrl, AUTH_REFRESH_PATH);
    let resp: Response;
    try {
      resp = await this.fetchImpl(url, {
        method: "POST",
        credentials: this.withCredentials ? "include" : "same-origin",
        headers: { Accept: "application/json" },
      });
    } catch {
      return null;
    }
    if (!resp.ok) return null;
    let body: unknown;
    try {
      body = await resp.json();
    } catch {
      return null;
    }
    const camel = snakeToCamelDeep(body) as { accessToken?: string | null } | null;
    const newToken = camel && typeof camel === "object" ? camel.accessToken ?? null : null;
    if (newToken && this.tokenStore) {
      try {
        await maybeResolve(this.tokenStore.set(newToken));
      } catch {
        /* ignore store failure */
      }
    }
    return newToken ?? null;
  }

  // --- Request building --------------------------------------------------

  private async buildRequest(
    method: HttpMethod,
    path: string,
    body: unknown,
    options: RequestOptions,
  ): Promise<{ url: string; init: RequestInit }> {
    const urlWithQuery = await this.buildUrl(path, options.query);
    const headers = new Headers(options.headers ?? {});
    if (!headers.has("Accept")) headers.set("Accept", "application/json");

    if (!options.skipAuthHeader && this.tokenStore) {
      const token = await maybeResolve(this.tokenStore.get());
      if (token && !headers.has("Authorization")) {
        headers.set("Authorization", `Bearer ${token}`);
      }
    }

    if (!options.skipWorkspaceIdHeader && !headers.has("X-Workspace-Id")) {
      const wsId = await this.resolveWorkspaceId(options);
      if (wsId) headers.set("X-Workspace-Id", wsId);
    }

    if (options.sharedDriveId && !headers.has("X-Shared-Drive-Id")) {
      headers.set("X-Shared-Drive-Id", options.sharedDriveId);
    }

    const init: RequestInit = {
      method,
      headers,
      credentials: this.withCredentials ? "include" : "same-origin",
    };

    const encoded = this.encodeBody(body, options);
    if (encoded !== undefined) {
      init.body = encoded.body;
      if (encoded.contentType && !headers.has("Content-Type")) {
        headers.set("Content-Type", encoded.contentType);
      }
    }

    return { url: urlWithQuery, init };
  }

  private async buildUrl(path: string, query: Record<string, unknown> | undefined): Promise<string> {
    const base = joinBaseAndPath(this.apiBaseUrl, path);
    const params = buildSnakeSearchParams(query);
    if (!params || [...params.keys()].length === 0) return base;
    const sep = base.includes("?") ? "&" : "?";
    return `${base}${sep}${params.toString()}`;
  }

  private async resolveWorkspaceId(options: RequestOptions): Promise<string | null> {
    if (options.workspaceId !== undefined) return options.workspaceId ?? null;
    if (this.workspaceStore) {
      const v = await maybeResolve(this.workspaceStore.get());
      return v ?? null;
    }
    return null;
  }

  private encodeBody(
    body: unknown,
    options: RequestOptions,
  ): { body: BodyInit; contentType?: string } | undefined {
    if (body === undefined || body === null) return undefined;

    if (isBinaryBody(body)) {
      if (typeof FormData !== "undefined" && body instanceof FormData && !options.skipRequestTransform) {
        return { body: snakeCaseFormData(body) };
      }
      return { body: body as BodyInit };
    }

    if (typeof body === "string") {
      return { body, contentType: "text/plain;charset=UTF-8" };
    }

    const transformed = options.skipRequestTransform ? body : camelToSnakeDeep(body);
    return { body: JSON.stringify(transformed), contentType: "application/json" };
  }

  private async parseResponseBody(response: Response, options: RequestOptions): Promise<unknown> {
    if (response.status === 204) return undefined;
    const contentType = response.headers.get("content-type") ?? "";

    if (options.skipResponseTransform) {
      return await response.blob();
    }

    if (contentType.startsWith("application/json") || contentType.includes("+json")) {
      const text = await response.text();
      if (!text) return undefined;
      let parsed: unknown;
      try {
        parsed = JSON.parse(text);
      } catch {
        return text;
      }
      return snakeToCamelDeep(parsed);
    }

    if (contentType.startsWith("text/")) {
      return await response.text();
    }

    return await response.blob();
  }
}

function isAuthPath(path: string): boolean {
  const p = path.startsWith("/") ? path : `/${path}`;
  return (
    p === "/auth/refresh" ||
    p === "/auth/login" ||
    p === "/auth/login/org" ||
    p === "/auth/logout" ||
    p.startsWith("/auth/callback/")
  );
}
