/**
 * camelCase ⇄ snake_case conversion helpers.
 *
 * - Mirrors the request/response transform that `ns-teamver-fe-v2/web/src/lib/api.ts`
 *   applies, so AI Apps FE that migrate to the SDK keep getting the same shapes.
 * - `FormData`, `Blob`, `ArrayBuffer`, `URLSearchParams` and `File` are deliberately
 *   passed through (BE expects original payload, not a re-encoded copy).
 *   For `FormData`, only the **field names** are snake-cased; file values are
 *   preserved as-is.
 */

const SNAKE_TO_CAMEL_RE = /_([a-z0-9])/g;
const CAMEL_TO_SNAKE_RE = /([a-z0-9])([A-Z])/g;

export function toSnakeKey(key: string): string {
  return key.replace(CAMEL_TO_SNAKE_RE, "$1_$2").toLowerCase();
}

export function toCamelKey(key: string): string {
  return key.replace(SNAKE_TO_CAMEL_RE, (_, c) => c.toUpperCase());
}

function isPlainObject(v: unknown): v is Record<string, unknown> {
  if (v === null || typeof v !== "object") return false;
  const proto = Object.getPrototypeOf(v);
  return proto === Object.prototype || proto === null;
}

function isBinaryLike(v: unknown): boolean {
  if (typeof Blob !== "undefined" && v instanceof Blob) return true;
  if (typeof ArrayBuffer !== "undefined" && v instanceof ArrayBuffer) return true;
  if (typeof FormData !== "undefined" && v instanceof FormData) return true;
  if (typeof URLSearchParams !== "undefined" && v instanceof URLSearchParams) return true;
  if (typeof File !== "undefined" && v instanceof File) return true;
  if (ArrayBuffer.isView(v as ArrayBufferView)) return true;
  return false;
}

export function camelToSnakeDeep<T = unknown>(value: T): T {
  if (value === null || value === undefined) return value;
  if (isBinaryLike(value)) return value;
  if (Array.isArray(value)) {
    return value.map((v) => camelToSnakeDeep(v)) as unknown as T;
  }
  if (isPlainObject(value)) {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) {
      out[toSnakeKey(k)] = camelToSnakeDeep(v);
    }
    return out as unknown as T;
  }
  return value;
}

export function snakeToCamelDeep<T = unknown>(value: T): T {
  if (value === null || value === undefined) return value;
  if (isBinaryLike(value)) return value;
  if (Array.isArray(value)) {
    return value.map((v) => snakeToCamelDeep(v)) as unknown as T;
  }
  if (isPlainObject(value)) {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) {
      out[toCamelKey(k)] = snakeToCamelDeep(v);
    }
    return out as unknown as T;
  }
  return value;
}

/** Snake-case the field names of a `FormData` while keeping File/Blob values intact. */
export function snakeCaseFormData(input: FormData): FormData {
  if (typeof FormData === "undefined") return input;
  const out = new FormData();
  for (const [key, value] of input.entries()) {
    out.append(toSnakeKey(key), value as Blob | string);
  }
  return out;
}

/** Build a `URLSearchParams` from an object, converting keys to snake_case. */
export function buildSnakeSearchParams(query: Record<string, unknown> | undefined): URLSearchParams | null {
  if (!query) return null;
  const params = new URLSearchParams();
  for (const [rawKey, rawVal] of Object.entries(query)) {
    if (rawVal === undefined || rawVal === null) continue;
    const key = toSnakeKey(rawKey);
    if (Array.isArray(rawVal)) {
      for (const v of rawVal) {
        if (v === undefined || v === null) continue;
        params.append(key, String(v));
      }
    } else if (typeof rawVal === "boolean") {
      params.append(key, rawVal ? "true" : "false");
    } else {
      params.append(key, String(rawVal));
    }
  }
  return params;
}
