import type { TokenStore, WorkspaceStore } from "./types";

/**
 * Token / Workspace store helpers — mirrors the behaviour of
 * `ns-teamver-fe-v2/web/src/lib/apiCredentials.ts` and `activeWorkspaceId.ts`.
 */

// ---------------------------------------------------------------------------
// Token stores
// ---------------------------------------------------------------------------

export interface CreateLocalStorageTokenStoreOptions {
  key?: string;
  storage?: Storage;
}

export function createLocalStorageTokenStore(
  options: CreateLocalStorageTokenStoreOptions = {},
): TokenStore {
  const key = options.key ?? "token";
  const storage = options.storage ?? safeLocalStorage();
  return {
    get() {
      if (!storage) return null;
      try {
        return storage.getItem(key);
      } catch {
        return null;
      }
    },
    set(value) {
      if (!storage) return;
      try {
        if (value == null) storage.removeItem(key);
        else storage.setItem(key, value);
      } catch {
        // swallow — quota / disabled storage should not break SDK
      }
    },
  };
}

/** In-memory token store — useful for SSR or short-lived test contexts. */
export function createMemoryTokenStore(initial?: string | null): TokenStore {
  let current: string | null = initial ?? null;
  return {
    get() {
      return current;
    },
    set(value) {
      current = value ?? null;
    },
  };
}

// ---------------------------------------------------------------------------
// Workspace stores
// ---------------------------------------------------------------------------

export interface CreateLocalStorageWorkspaceStoreOptions {
  /** Key for the currently active workspace id. */
  activeKey?: string;
  /** Key for the per-user "last selected" map (JSON). */
  lastByUserKey?: string;
  storage?: Storage;
}

export interface LocalStorageWorkspaceStore extends WorkspaceStore {
  /** Look up the workspace last used by a given user (for bootstrap). */
  getLastForUser(userId: string | null | undefined): string | null;
  /** Record the workspace last used by a given user. */
  setLastForUser(userId: string | null | undefined, workspaceId: string | null): void;
  /** Convenience: pick best workspace id on app boot — active or last-by-user. */
  getPreferredWorkspaceIdForBootstrap(userId: string | null | undefined): string | null;
}

export function createLocalStorageWorkspaceStore(
  options: CreateLocalStorageWorkspaceStoreOptions = {},
): LocalStorageWorkspaceStore {
  const activeKey = options.activeKey ?? "teamver_active_workspace_id";
  const lastByUserKey = options.lastByUserKey ?? "teamver_last_workspace_by_user";
  const storage = options.storage ?? safeLocalStorage();

  function readMap(): Record<string, string> {
    if (!storage) return {};
    try {
      const raw = storage.getItem(lastByUserKey);
      if (!raw) return {};
      const parsed = JSON.parse(raw);
      return parsed && typeof parsed === "object" ? (parsed as Record<string, string>) : {};
    } catch {
      return {};
    }
  }

  function writeMap(map: Record<string, string>): void {
    if (!storage) return;
    try {
      storage.setItem(lastByUserKey, JSON.stringify(map));
    } catch {
      // swallow
    }
  }

  const store: LocalStorageWorkspaceStore = {
    get() {
      if (!storage) return null;
      try {
        return storage.getItem(activeKey);
      } catch {
        return null;
      }
    },
    set(workspaceId) {
      if (!storage) return;
      try {
        if (workspaceId == null) storage.removeItem(activeKey);
        else storage.setItem(activeKey, workspaceId);
      } catch {
        // swallow
      }
    },
    getLastForUser(userId) {
      if (!userId) return null;
      return readMap()[userId] ?? null;
    },
    setLastForUser(userId, workspaceId) {
      if (!userId) return;
      const map = readMap();
      if (workspaceId == null) {
        delete map[userId];
      } else {
        map[userId] = workspaceId;
      }
      writeMap(map);
    },
    getPreferredWorkspaceIdForBootstrap(userId) {
      const active = store.get();
      if (typeof active === "string" && active) return active;
      if (userId) return store.getLastForUser(userId);
      return null;
    },
  };

  return store;
}

/** In-memory workspace store — used in tests and SSR. */
export function createMemoryWorkspaceStore(initial?: string | null): WorkspaceStore {
  let current: string | null = initial ?? null;
  return {
    get() {
      return current;
    },
    set(value) {
      current = value ?? null;
    },
  };
}

function safeLocalStorage(): Storage | null {
  try {
    if (typeof globalThis !== "undefined" && "localStorage" in globalThis) {
      return (globalThis as { localStorage: Storage }).localStorage;
    }
  } catch {
    // fallthrough
  }
  return null;
}
