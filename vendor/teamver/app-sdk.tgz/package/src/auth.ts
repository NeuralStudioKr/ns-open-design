import type { TeamverHttpClient } from "./http";
import type { LoginResponse, LogoutResponse, RequestOptions } from "./types";

/**
 * Auth wrapper for `/api/auth/*`.
 *
 * - login endpoints never need a workspace header (no member context yet).
 * - logout/refresh respect the cookie session that main BE issues.
 */
export class AuthClient {
  constructor(private readonly http: TeamverHttpClient) {}

  async login(email: string, password: string, options: RequestOptions = {}): Promise<LoginResponse> {
    return this.http.post<LoginResponse>(
      "/auth/login",
      { email, password },
      {
        skipWorkspaceIdHeader: true,
        skipAuthHeader: true,
        skipAuthRecovery: true,
        ...options,
      },
    );
  }

  async loginOrg(
    params: { workspaceId: string; email: string; password: string },
    options: RequestOptions = {},
  ): Promise<LoginResponse> {
    return this.http.post<LoginResponse>("/auth/login/org", params, {
      skipWorkspaceIdHeader: true,
      skipAuthHeader: true,
      skipAuthRecovery: true,
      ...options,
    });
  }

  async refresh(options: RequestOptions = {}): Promise<{ accessToken: string | null }> {
    return this.http.post<{ accessToken: string | null }>(
      "/auth/refresh",
      undefined,
      {
        skipWorkspaceIdHeader: true,
        skipAuthHeader: true,
        skipAuthRecovery: true,
        ...options,
      },
    );
  }

  async logout(
    params: { logoutRedirectUri?: string } = {},
    options: RequestOptions = {},
  ): Promise<LogoutResponse> {
    return this.http.post<LogoutResponse>("/auth/logout", params, {
      skipWorkspaceIdHeader: true,
      skipAuthRecovery: true,
      ...options,
    });
  }
}
