import type { TeamverHttpClient } from "./http";
import type {
  BillingCheckoutInput,
  BillingCheckoutResponse,
  AppServiceRegistryCredentials,
  RegistryBillingCommitInput,
  RegistryBillingCommitResponse,
  RegistryBillingRefundInput,
  RegistryBillingRefundResponse,
  RegistryBillingReserveInput,
  RegistryBillingReserveResponse,
  RegisterBillingCallbackInput,
  ReplaceCardInput,
  ReplaceCardResponse,
  RequestOptions,
} from "./types";

function registryHeaders(credentials: AppServiceRegistryCredentials): Record<string, string> {
  return {
    "X-Teamver-App-Id": credentials.appId,
    "X-Teamver-Key-Id": credentials.keyId,
    "X-Teamver-Access-Key": credentials.accessKey,
  };
}

/** `/api/billing/*` wrapper. */
export class BillingClient {
  constructor(private readonly http: TeamverHttpClient) {}

  async checkout(
    input: BillingCheckoutInput,
    options: RequestOptions = {},
  ): Promise<BillingCheckoutResponse> {
    return this.http.post<BillingCheckoutResponse>("/billing/checkout", input, options);
  }

  async registerCallback(
    input: RegisterBillingCallbackInput,
    options: RequestOptions = {},
  ): Promise<{ success?: boolean; message?: string }> {
    return this.http.post<{ success?: boolean; message?: string }>(
      "/billing/register-callback",
      input,
      options,
    );
  }

  async replaceCard(
    input: ReplaceCardInput,
    options: RequestOptions = {},
  ): Promise<ReplaceCardResponse> {
    return this.http.post<ReplaceCardResponse>("/billing/replace-card", input, options);
  }

  async removePaymentMethod(
    options: RequestOptions = {},
  ): Promise<{ success?: boolean; message?: string }> {
    return this.http.post<{ success?: boolean; message?: string }>(
      "/billing/remove-payment-method",
      undefined,
      options,
    );
  }

  /** Registry access key — AI App BE reserve/commit/refund (116 §10.4–10.6). */
  async reserveRegistry(
    input: RegistryBillingReserveInput,
    credentials: AppServiceRegistryCredentials,
    options: RequestOptions = {},
  ): Promise<RegistryBillingReserveResponse> {
    return this.http.post<RegistryBillingReserveResponse>(
      "/billing/reserve",
      input,
      {
        skipAuthHeader: true,
        skipWorkspaceIdHeader: true,
        headers: { ...registryHeaders(credentials), ...options.headers },
        ...options,
      },
    );
  }

  async commitRegistry(
    input: RegistryBillingCommitInput,
    credentials: AppServiceRegistryCredentials,
    options: RequestOptions = {},
  ): Promise<RegistryBillingCommitResponse> {
    return this.http.post<RegistryBillingCommitResponse>(
      "/billing/commit",
      input,
      {
        skipAuthHeader: true,
        skipWorkspaceIdHeader: true,
        headers: { ...registryHeaders(credentials), ...options.headers },
        ...options,
      },
    );
  }

  async refundRegistry(
    input: RegistryBillingRefundInput,
    credentials: AppServiceRegistryCredentials,
    options: RequestOptions = {},
  ): Promise<RegistryBillingRefundResponse> {
    return this.http.post<RegistryBillingRefundResponse>(
      "/billing/refund",
      input,
      {
        skipAuthHeader: true,
        skipWorkspaceIdHeader: true,
        headers: { ...registryHeaders(credentials), ...options.headers },
        ...options,
      },
    );
  }
}
