import type { TeamverHttpClient } from "./http";
import type {
  DriveFolderTreeResponse,
  RequestOptions,
  SharedDrive,
  SharedDriveAccessCheckResponse,
  SharedDriveCreateInput,
  SharedDriveListParams,
  SharedDriveUpdateInput,
} from "./types";

function normalizeArray<T>(raw: unknown, keys: string[] = ["items", "data", "results"]): T[] {
  if (Array.isArray(raw)) return raw as T[];
  if (raw && typeof raw === "object") {
    const r = raw as Record<string, unknown>;
    for (const k of keys) {
      if (Array.isArray(r[k])) return r[k] as T[];
    }
  }
  return [];
}

/** `/api/v2/shared-drive/*` wrapper. */
export class SharedDriveClient {
  constructor(private readonly http: TeamverHttpClient) {}

  async list(params: SharedDriveListParams = {}, options: RequestOptions = {}): Promise<SharedDrive[]> {
    const raw = await this.http.get<unknown>("/v2/shared-drive", {
      query: params as Record<string, unknown>,
      ...options,
    });
    return normalizeArray<SharedDrive>(raw);
  }

  async get(driveId: string, options: RequestOptions = {}): Promise<SharedDrive> {
    return this.http.get<SharedDrive>(`/v2/shared-drive/${encodeURIComponent(driveId)}`, options);
  }

  async create(input: SharedDriveCreateInput, options: RequestOptions = {}): Promise<SharedDrive> {
    return this.http.post<SharedDrive>("/v2/shared-drive", input, options);
  }

  async update(
    driveId: string,
    input: SharedDriveUpdateInput,
    options: RequestOptions = {},
  ): Promise<SharedDrive> {
    return this.http.patch<SharedDrive>(
      `/v2/shared-drive/${encodeURIComponent(driveId)}`,
      input,
      options,
    );
  }

  async archive(driveId: string, options: RequestOptions = {}): Promise<void> {
    await this.http.delete<unknown>(`/v2/shared-drive/${encodeURIComponent(driveId)}`, options);
  }

  async restore(driveId: string, options: RequestOptions = {}): Promise<SharedDrive> {
    return this.http.post<SharedDrive>(
      `/v2/shared-drive/${encodeURIComponent(driveId)}/restore`,
      undefined,
      options,
    );
  }

  async purge(driveId: string, options: RequestOptions = {}): Promise<void> {
    await this.http.delete<unknown>(
      `/v2/shared-drive/${encodeURIComponent(driveId)}/purge`,
      options,
    );
  }

  async leave(driveId: string, options: RequestOptions = {}): Promise<void> {
    await this.http.delete<unknown>(
      `/v2/shared-drive/${encodeURIComponent(driveId)}/member/me`,
      options,
    );
  }

  async folderTree(driveId: string, options: RequestOptions = {}): Promise<DriveFolderTreeResponse> {
    const raw = await this.http.get<unknown>(
      `/v2/shared-drive/${encodeURIComponent(driveId)}/folder-tree`,
      { timeoutMs: 120_000, ...options },
    );
    if (raw && typeof raw === "object" && !Array.isArray(raw)) {
      const r = raw as Record<string, unknown>;
      if (Array.isArray(r.tree)) return raw as DriveFolderTreeResponse;
      if (Array.isArray(r.items)) return { ...r, tree: r.items as DriveFolderTreeResponse["tree"] };
    }
    if (Array.isArray(raw)) return { tree: raw as DriveFolderTreeResponse["tree"] };
    return { tree: [] };
  }

  async accessCheck(
    driveId: string,
    options: RequestOptions = {},
  ): Promise<SharedDriveAccessCheckResponse> {
    return this.http.get<SharedDriveAccessCheckResponse>(
      `/v2/shared-drive/${encodeURIComponent(driveId)}/access-check`,
      options,
    );
  }
}
