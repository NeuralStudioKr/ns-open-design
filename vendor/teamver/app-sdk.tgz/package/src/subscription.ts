import type { TeamverHttpClient } from "./http";
import type { RequestOptions, SubscriptionMeResponse } from "./types";

/**
 * `/api/subscription/*` wrapper.
 *
 * `getMe()` skips the workspace header by default — a stale active workspace id
 * must not cause the entire billing screen to 403. Callers that need to read a
 * specific team's subscription should pass `{ workspaceId }`.
 */
export class SubscriptionClient {
  constructor(private readonly http: TeamverHttpClient) {}

  async getMe(options: RequestOptions = {}): Promise<SubscriptionMeResponse> {
    // Default: skip the workspace header so a stale active id never blocks
    // bootstrap. Callers can pass an explicit `workspaceId` (team billing) or
    // `skipWorkspaceIdHeader: false` to override.
    const skipWorkspaceIdHeader =
      options.skipWorkspaceIdHeader ?? options.workspaceId == null;
    return this.http.get<SubscriptionMeResponse>("/subscription/me", {
      ...options,
      skipWorkspaceIdHeader,
    });
  }

  async createOrChange(
    planId: string,
    billingCycle?: string,
    options: RequestOptions = {},
  ): Promise<SubscriptionMeResponse> {
    return this.http.post<SubscriptionMeResponse>(
      "/subscription",
      { planId, billingCycle },
      options,
    );
  }

  async cancelAtPeriodEnd(options: RequestOptions = {}): Promise<SubscriptionMeResponse> {
    return this.http.post<SubscriptionMeResponse>("/subscription/cancel", undefined, options);
  }
}
