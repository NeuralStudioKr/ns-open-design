import { snakeCaseFormData } from "./casing";
import { TeamverApiError } from "./errors";
import type { TeamverHttpClient } from "./http";
import type {
  AssetSharingOverviewResponse,
  CursorPaginatedResponse,
  DriveAssetItem,
  DriveDownloadParams,
  DriveDownloadUrlResponse,
  DriveFolderTreeParams,
  DriveFolderTreeResponse,
  DriveHomeRecentParams,
  DriveHomeRecentResponse,
  DriveHomeSearchParams,
  DriveHomeSearchResponse,
  DriveListItem,
  DriveListParams,
  DriveSharingParams,
  DriveUploadConfirmResponse,
  DriveUploadFileInput,
  DriveUploadRequestInput,
  DriveUploadTicket,
  RequestOptions,
} from "./types";

const LONG_RUNNING_TIMEOUT_MS = 120_000;

function isFile(value: unknown): value is File {
  return typeof File !== "undefined" && value instanceof File;
}

function isBlob(value: unknown): value is Blob {
  return typeof Blob !== "undefined" && value instanceof Blob;
}

function normalizeUploadConfirmError(err: unknown): { alreadyDone: boolean } {
  if (err instanceof TeamverApiError && err.status === 400) {
    const key = err.messageKey ?? err.code ?? "";
    const lower = typeof key === "string" ? key.toLowerCase() : "";
    if (
      lower.includes("already") ||
      lower.includes("duplicate") ||
      lower.includes("done") ||
      err.code === "ALREADY_CONFIRMED"
    ) {
      return { alreadyDone: true };
    }
  }
  return { alreadyDone: false };
}

function normalizeDriveListResponse(raw: unknown): CursorPaginatedResponse<DriveListItem> {
  if (Array.isArray(raw)) return { items: raw as DriveListItem[] };
  if (raw && typeof raw === "object") {
    const r = raw as Record<string, unknown>;
    const items =
      (Array.isArray(r.items) && (r.items as DriveListItem[])) ||
      (Array.isArray(r.data) && (r.data as DriveListItem[])) ||
      (Array.isArray(r.results) && (r.results as DriveListItem[])) ||
      [];
    return {
      items,
      nextCursor: (r.nextCursor as string | null | undefined) ?? null,
      hasMore: r.hasMore as boolean | undefined,
      ...r,
    };
  }
  return { items: [] };
}

function normalizeFolderTree(raw: unknown): DriveFolderTreeResponse {
  if (Array.isArray(raw)) return { tree: raw as DriveFolderTreeResponse["tree"] };
  if (raw && typeof raw === "object") {
    const r = raw as Record<string, unknown>;
    if (Array.isArray(r.tree)) return raw as DriveFolderTreeResponse;
    if (Array.isArray(r.items)) return { ...r, tree: r.items as DriveFolderTreeResponse["tree"] };
    if (Array.isArray(r.children)) return { ...r, tree: r.children as DriveFolderTreeResponse["tree"] };
  }
  return { tree: [] };
}

/**
 * `/api/drive/*` + `/api/v2/drive/*` wrapper.
 *
 * - All endpoints that take a `sharedDriveId` automatically attach the
 *   `X-Shared-Drive-Id` header and `shared_drive_id` field, matching
 *   `ns-teamver-fe-v2/web/src/services/drive.ts`.
 * - Upload follows the presigned 3-step contract (request → S3 PUT → confirm).
 */
export class DriveClient {
  constructor(private readonly http: TeamverHttpClient) {}

  async list(
    params: DriveListParams = {},
    options: RequestOptions = {},
  ): Promise<CursorPaginatedResponse<DriveListItem>> {
    const { sharedDriveId, ...rest } = params;
    const raw = await this.http.get<unknown>("/drive/list", {
      query: rest as Record<string, unknown>,
      sharedDriveId: sharedDriveId ?? options.sharedDriveId ?? null,
      ...options,
    });
    return normalizeDriveListResponse(raw);
  }

  async folderTree(
    params: DriveFolderTreeParams = {},
    options: RequestOptions = {},
  ): Promise<DriveFolderTreeResponse> {
    const { sharedDriveId, ...rest } = params;
    const raw = await this.http.get<unknown>("/drive/folder/tree", {
      query: rest as Record<string, unknown>,
      sharedDriveId: sharedDriveId ?? options.sharedDriveId ?? null,
      timeoutMs: options.timeoutMs ?? LONG_RUNNING_TIMEOUT_MS,
      ...options,
    });
    return normalizeFolderTree(raw);
  }

  async homeSearch(
    params: DriveHomeSearchParams,
    options: RequestOptions = {},
  ): Promise<DriveHomeSearchResponse> {
    const { sharedDriveId, ...rest } = params;
    const raw = await this.http.get<unknown>("/v2/drive/home/search", {
      query: rest as Record<string, unknown>,
      sharedDriveId: sharedDriveId ?? options.sharedDriveId ?? null,
      ...options,
    });
    if (raw && typeof raw === "object" && !Array.isArray(raw)) {
      const r = raw as Record<string, unknown>;
      if (Array.isArray(r.items)) return raw as DriveHomeSearchResponse;
      if (Array.isArray(r.results)) return { ...r, items: r.results as DriveAssetItem[] };
    }
    if (Array.isArray(raw)) return { items: raw as DriveAssetItem[] };
    return { items: [] };
  }

  async homeRecent(
    params: DriveHomeRecentParams = {},
    options: RequestOptions = {},
  ): Promise<DriveHomeRecentResponse> {
    const { sharedDriveId, ...rest } = params;
    const raw = await this.http.get<unknown>("/v2/drive/home/recent", {
      query: rest as Record<string, unknown>,
      sharedDriveId: sharedDriveId ?? options.sharedDriveId ?? null,
      ...options,
    });
    if (Array.isArray(raw)) return { items: raw as DriveAssetItem[] };
    if (raw && typeof raw === "object") {
      const r = raw as Record<string, unknown>;
      if (Array.isArray(r.items)) return raw as DriveHomeRecentResponse;
      if (Array.isArray(r.results)) return { ...r, items: r.results as DriveAssetItem[] };
    }
    return { items: [] };
  }

  async folderLocation(folderId: string, options: RequestOptions = {}): Promise<unknown> {
    return this.http.get<unknown>(
      `/v2/drive/folder/${encodeURIComponent(folderId)}/location`,
      options,
    );
  }

  async getDownloadUrl(
    assetId: string,
    params: DriveDownloadParams = {},
    options: RequestOptions = {},
  ): Promise<DriveDownloadUrlResponse> {
    return this.http.get<DriveDownloadUrlResponse>(
      `/drive/asset/${encodeURIComponent(assetId)}/download-url`,
      {
        sharedDriveId: params.sharedDriveId ?? options.sharedDriveId ?? null,
        ...options,
      },
    );
  }

  /**
   * Browser helper — request the download URL then trigger an `<a download>`.
   * On non-browser runtimes this throws.
   */
  async download(
    assetId: string,
    params: DriveDownloadParams & { fallbackFilename?: string } = {},
    options: RequestOptions = {},
  ): Promise<void> {
    if (typeof document === "undefined") {
      throw new Error("DriveClient.download() requires a browser environment.");
    }
    const result = await this.getDownloadUrl(assetId, params, options);
    const a = document.createElement("a");
    a.href = result.downloadUrl;
    a.download = result.filename ?? params.fallbackFilename ?? "";
    a.style.display = "none";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  async createUploadRequest(
    input: DriveUploadRequestInput,
    options: RequestOptions = {},
  ): Promise<DriveUploadTicket> {
    return this.http.post<DriveUploadTicket>("/drive/upload-request", input, {
      sharedDriveId: input.sharedDriveId ?? options.sharedDriveId ?? null,
      ...options,
    });
  }

  async confirmUpload(
    assetId: string,
    options: RequestOptions & { sharedDriveId?: string | null } = {},
  ): Promise<DriveUploadConfirmResponse> {
    try {
      const resp = await this.http.post<DriveUploadConfirmResponse>(
        "/drive/upload-confirm",
        { assetId },
        {
          sharedDriveId: options.sharedDriveId ?? null,
          ...options,
        },
      );
      return resp ?? {};
    } catch (err) {
      const { alreadyDone } = normalizeUploadConfirmError(err);
      if (alreadyDone) return { alreadyConfirmed: true };
      throw err;
    }
  }

  /**
   * Full upload-orchestration helper.
   *
   * MVP progress is coarse: 0 on start, 0.5 after the S3 PUT begins, 1 after
   * confirm succeeds. Pass a custom `presignedPutAdapter` to wire up XHR-based
   * progress in app land.
   */
  async uploadFile(
    file: File | Blob,
    input: DriveUploadFileInput = {},
    options: RequestOptions = {},
  ): Promise<DriveAssetItem> {
    if (!isFile(file) && !isBlob(file)) {
      throw new TypeError("uploadFile() requires a File or Blob.");
    }
    const filename =
      input.filename ??
      ((file as File).name as string | undefined) ??
      "upload.bin";
    const contentType =
      input.contentType ??
      ((file as File).type as string | undefined) ??
      "application/octet-stream";
    const sizeBytes = file.size;
    input.onProgress?.(0);

    const ticket = await this.createUploadRequest(
      {
        filename,
        contentType,
        sizeBytes,
        folderId: input.folderId ?? null,
        sharedDriveId: input.sharedDriveId ?? null,
        kind: input.kind ?? "uploaded",
      },
      options,
    );

    input.onProgress?.(0.25);

    if (input.presignedPutAdapter) {
      await input.presignedPutAdapter(ticket, file);
    } else {
      await uploadToS3Presigned(ticket, file, contentType, this.http.fetchImpl);
    }

    input.onProgress?.(0.75);

    const confirm = await this.confirmUpload(ticket.assetId, {
      sharedDriveId: input.sharedDriveId ?? null,
      ...options,
    });

    input.onProgress?.(1);

    const asset: DriveAssetItem =
      confirm.asset ?? {
        assetId: ticket.assetId,
        name: filename,
        kind: input.kind ?? "uploaded",
        type: contentType,
        folderId: input.folderId ?? null,
        sharedDriveId: input.sharedDriveId ?? null,
        sizeBytes,
        uploadStatus: confirm.alreadyConfirmed ? "ready" : "ready",
      };
    return asset;
  }

  async getSharing(
    assetId: string,
    params: DriveSharingParams = {},
    options: RequestOptions = {},
  ): Promise<AssetSharingOverviewResponse> {
    const sharedDriveId = params.sharedDriveId ?? options.sharedDriveId ?? null;
    const basePath = sharedDriveId
      ? `/v2/shared-drive/${encodeURIComponent(sharedDriveId)}/asset/${encodeURIComponent(
          assetId,
        )}/sharing`
      : `/drive/asset/${encodeURIComponent(assetId)}/sharing`;
    return this.http.get<AssetSharingOverviewResponse>(basePath, {
      sharedDriveId,
      ...options,
    });
  }
}

/** Default S3 PUT — fetch-based, no progress events. */
async function uploadToS3Presigned(
  ticket: DriveUploadTicket,
  file: File | Blob,
  contentType: string,
  fetchImpl: typeof fetch,
): Promise<void> {
  const headers: Record<string, string> = {
    "Content-Type": contentType,
    ...(ticket.headers ?? {}),
  };
  // S3 must NOT receive cookies or our auth header — bypass the API client.
  const resp = await fetchImpl(ticket.presignedUrl, {
    method: ticket.method ?? "PUT",
    body: file,
    headers,
  });
  if (!resp.ok) {
    throw new TeamverApiError({
      status: resp.status,
      code: "S3_UPLOAD_FAILED",
      message: `S3 presigned PUT failed (${resp.status})`,
    });
  }
}

// Re-export so consumers can implement custom adapters in TS.
export { snakeCaseFormData };
