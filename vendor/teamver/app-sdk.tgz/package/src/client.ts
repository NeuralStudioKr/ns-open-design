import { AppServiceClient } from "./appService";
import { AuthClient } from "./auth";
import { BillingClient } from "./billing";
import { CreditsClient } from "./credits";
import { DriveClient } from "./drive";
import { TeamverHttpClient } from "./http";
import { SharedDriveClient } from "./sharedDrive";
import { SubscriptionClient } from "./subscription";
import { UserClient } from "./user";
import { WorkspaceClient } from "./workspace";
import type {
  TeamverAppConfig,
  TeamverClientConfig,
  TokenStore,
  WorkspaceStore,
} from "./types";

/**
 * Single entry-point client.
 *
 * Mirrors the `TeamverClient` shape described in
 * `docs/01_2_FE용_typescript_SDK_UI_상세_구현_설계.md` §4.1. Domain wrappers are
 * exposed as properties so apps can call e.g. `client.workspace.listMine()`.
 */
export class TeamverClient {
  readonly config: TeamverClientConfig;
  readonly http: TeamverHttpClient;

  readonly auth: AuthClient;
  readonly user: UserClient;
  readonly workspace: WorkspaceClient;
  readonly drive: DriveClient;
  readonly sharedDrive: SharedDriveClient;
  readonly billing: BillingClient;
  readonly credits: CreditsClient;
  readonly subscription: SubscriptionClient;
  readonly appService: AppServiceClient;

  constructor(config: TeamverClientConfig = {}) {
    this.config = config;
    this.http = new TeamverHttpClient(config);
    this.auth = new AuthClient(this.http);
    this.user = new UserClient(this.http);
    this.workspace = new WorkspaceClient(this.http);
    this.drive = new DriveClient(this.http);
    this.sharedDrive = new SharedDriveClient(this.http);
    this.billing = new BillingClient(this.http);
    this.credits = new CreditsClient(this.http);
    this.subscription = new SubscriptionClient(this.http);
    this.appService = new AppServiceClient(this.http);
  }

  get tokenStore(): TokenStore | null {
    return this.http.tokenStore;
  }

  get workspaceStore(): WorkspaceStore | null {
    return this.http.workspaceStore;
  }

  /** Convenience: drop the locally cached access token. */
  async clearAccessToken(): Promise<void> {
    if (this.http.tokenStore) {
      await this.http.tokenStore.set(null);
    }
  }
}

/**
 * Functional constructor — kept as a thin wrapper for back-compat with the
 * placeholder `createTeamverAppClient` exported by the previous SDK scaffold.
 */
export function createTeamverAppClient(config: TeamverAppConfig = {}): TeamverClient {
  return new TeamverClient(config);
}
