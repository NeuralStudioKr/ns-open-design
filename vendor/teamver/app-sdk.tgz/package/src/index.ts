export { AppServiceClient } from "./appService";
export { TeamverClient, createTeamverAppClient } from "./client";
export {
  DEFAULT_API_BASE_URL,
  DEFAULT_REQUEST_TIMEOUT_MS,
  TeamverHttpClient,
  normalizeApiBaseUrl,
} from "./http";

export { AuthClient } from "./auth";
export { UserClient } from "./user";
export { WorkspaceClient } from "./workspace";
export { DriveClient } from "./drive";
export { SharedDriveClient } from "./sharedDrive";
export { BillingClient } from "./billing";
export { CreditsClient } from "./credits";
export { SubscriptionClient } from "./subscription";

export {
  createLocalStorageTokenStore,
  createLocalStorageWorkspaceStore,
  createMemoryTokenStore,
  createMemoryWorkspaceStore,
} from "./stores";
export type {
  CreateLocalStorageTokenStoreOptions,
  CreateLocalStorageWorkspaceStoreOptions,
  LocalStorageWorkspaceStore,
} from "./stores";

export {
  buildSnakeSearchParams,
  camelToSnakeDeep,
  snakeCaseFormData,
  snakeToCamelDeep,
  toCamelKey,
  toSnakeKey,
} from "./casing";

export {
  AuthenticationError,
  ForbiddenError,
  LoginProviderMismatchError,
  MainBEUnavailableError,
  NetworkError,
  NotFoundError,
  QuotaExceededError,
  RateLimitError,
  TeamverApiError,
  ValidationError,
  mapHttpErrorBody,
} from "./errors";
export type {
  LoginProviderMismatchInit,
  QuotaExceededInit,
  TeamverApiErrorInit,
} from "./errors";

export type * from "./types";
