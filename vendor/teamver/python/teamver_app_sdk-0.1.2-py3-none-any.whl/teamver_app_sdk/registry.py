from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AppServiceRegistryCredentials:
    app_id: str
    key_id: str
    access_key: str


def registry_headers(credentials: AppServiceRegistryCredentials) -> dict[str, str]:
    return {
        "X-Teamver-App-Id": credentials.app_id,
        "X-Teamver-Key-Id": credentials.key_id,
        "X-Teamver-Access-Key": credentials.access_key,
    }
