from __future__ import annotations

from typing import Any

from teamver_app_sdk.auth import extract_access_token_from_headers
from teamver_app_sdk.client import TeamverAppClient
from teamver_app_sdk.errors import (
    AppDisabledError,
    AuthenticationError,
    InvalidInternalApiKey,
    PermissionDeniedError,
    TeamverAPIError,
    TeamverInternalKeyNotConfigured,
    WorkspaceNotFoundError,
)

try:  # pragma: no cover - exercised when FastAPI extra is installed
    from fastapi import Header, HTTPException, Request
except ImportError:  # pragma: no cover - keeps core importable without FastAPI
    Header = None  # type: ignore[assignment]
    Request = Any  # type: ignore[misc,assignment]

    class HTTPException(Exception):  # type: ignore[no-redef]
        def __init__(self, *, status_code: int, detail: str) -> None:
            super().__init__(detail)
            self.status_code = status_code
            self.detail = detail


def create_teamver_context_dependency(
    client: TeamverAppClient,
    *,
    require_workspace: bool = True,
    require_app_enabled: bool = True,
):
    authorization_default = Header(default=None) if Header else None
    workspace_default = Header(default=None, alias="X-Workspace-Id") if Header else None

    async def dep(
        request: Request,
        authorization: str | None = authorization_default,
        x_workspace_id: str | None = workspace_default,
    ):
        cookie_token = getattr(request, "cookies", {}).get(client.config.auth_cookie_name)
        token = extract_access_token_from_headers(
            authorization=authorization,
            cookie_token=cookie_token,
        )
        if not token:
            raise HTTPException(status_code=401, detail="Teamver login required")
        try:
            return await client.auth.resolve_context(
                access_token=token,
                workspace_id=x_workspace_id if require_workspace else None,
                require_app_enabled=require_app_enabled,
            )
        except AuthenticationError as exc:
            raise HTTPException(status_code=401, detail=exc.code or str(exc)) from exc
        except WorkspaceNotFoundError as exc:
            raise HTTPException(status_code=404, detail=exc.code or str(exc)) from exc
        except (AppDisabledError, PermissionDeniedError) as exc:
            raise HTTPException(status_code=403, detail=exc.code or str(exc)) from exc

    return dep


def require_teamver_internal_api_key(expected: str):
    from teamver_app_sdk.m2m import verify_internal_api_key

    header_default = Header(default=None, alias="X-Teamver-Internal-Api-Key") if Header else None

    async def dep(x_teamver_internal_api_key: str | None = header_default) -> None:
        try:
            verify_internal_api_key(
                provided=x_teamver_internal_api_key,
                expected=expected,
            )
        except InvalidInternalApiKey as exc:
            raise HTTPException(status_code=401, detail=exc.code or str(exc)) from exc
        except TeamverInternalKeyNotConfigured as exc:
            raise HTTPException(status_code=500, detail=exc.code or str(exc)) from exc
        except TeamverAPIError as exc:
            raise HTTPException(status_code=500, detail=exc.code or str(exc)) from exc

    return dep
