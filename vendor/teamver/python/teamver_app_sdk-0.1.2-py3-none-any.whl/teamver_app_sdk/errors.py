from __future__ import annotations

from typing import Any


class TeamverAPIError(Exception):
    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        code: str | None = None,
        params: dict[str, Any] | None = None,
        response_body: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.params = params or {}
        self.response_body = response_body


class AuthenticationError(TeamverAPIError):
    pass


class AuthorizationError(TeamverAPIError):
    pass


class PermissionDeniedError(AuthorizationError):
    pass


class AppDisabledError(AuthorizationError):
    pass


class WorkspaceNotFoundError(TeamverAPIError):
    pass


class QuotaExceededError(PermissionDeniedError):
    pass


class RateLimitError(TeamverAPIError):
    pass


class MainBEUnavailableError(TeamverAPIError):
    pass


class DriveUploadError(TeamverAPIError):
    pass


class DriveConfirmError(TeamverAPIError):
    pass


class DriveDownloadError(TeamverAPIError):
    pass


class TeamverInternalKeyNotConfigured(TeamverAPIError):
    pass


class InvalidInternalApiKey(AuthenticationError):
    pass


def extract_error_code(response_body: Any) -> tuple[str | None, dict[str, Any]]:
    if isinstance(response_body, dict):
        if isinstance(response_body.get("detail"), dict):
            detail = response_body["detail"]
            code = detail.get("message") or detail.get("code")
            params = detail.get("params")
            return (
                str(code) if code is not None else None,
                params if isinstance(params, dict) else {},
            )
        if response_body.get("error") == "QUOTA_EXCEEDED":
            detail = response_body.get("detail")
            return (
                "QUOTA_EXCEEDED",
                detail if isinstance(detail, dict) else {},
            )
        code = response_body.get("message") or response_body.get("error") or response_body.get("detail")
        return str(code) if code is not None else None, {}
    if isinstance(response_body, str):
        return response_body, {}
    return None, {}


def map_http_error(status_code: int, response_body: Any) -> TeamverAPIError:
    code, params = extract_error_code(response_body)
    message = code or f"main BE request failed with status {status_code}"
    kwargs = {
        "status_code": status_code,
        "code": code,
        "params": params,
        "response_body": response_body,
    }
    if status_code == 401:
        return AuthenticationError(message, **kwargs)
    if code and "app_disabled" in code:
        return AppDisabledError(message, **kwargs)
    if status_code == 403 and code == "QUOTA_EXCEEDED":
        return QuotaExceededError(message, **kwargs)
    if status_code == 403:
        return PermissionDeniedError(message, **kwargs)
    if status_code == 404:
        return WorkspaceNotFoundError(message, **kwargs)
    if status_code == 429:
        return RateLimitError(message, **kwargs)
    if status_code >= 500:
        return MainBEUnavailableError(message, **kwargs)
    return TeamverAPIError(message, **kwargs)
