import os
from typing import cast

from pydantic import BaseModel, Field, field_validator

from teamver_app_sdk.enums import AppKey


class TeamverAppConfig(BaseModel):
    api_base_url: str
    app_key: AppKey = AppKey.MAIL
    bootstrap_cache_ttl_seconds: int = Field(default=120, ge=0)
    timeout_seconds: float = Field(default=10.0, gt=0)
    max_retries: int = Field(default=2, ge=0)
    retry_backoff_seconds: float = Field(default=0.25, ge=0)
    auth_cookie_name: str = "teamver_access_token"
    user_agent: str = "teamver-app-sdk-python/0.1.1"

    @classmethod
    def from_env(cls, *, app_key: AppKey | None = None) -> "TeamverAppConfig":
        api_base_url = os.getenv("TEAMVER_API_BASE_URL", "").strip()
        if not api_base_url:
            raise ValueError("TEAMVER_API_BASE_URL is required")
        env_key = os.getenv("TEAMVER_APP_KEY", AppKey.MAIL.value)
        resolved_app_key = app_key or cast(AppKey, env_key)
        return cls(
            api_base_url=api_base_url,
            app_key=resolved_app_key,
            bootstrap_cache_ttl_seconds=int(
                os.getenv("TEAMVER_BOOTSTRAP_CACHE_TTL_SECONDS", "120")
            ),
            timeout_seconds=float(os.getenv("TEAMVER_HTTP_TIMEOUT_SECONDS", "10")),
            max_retries=int(os.getenv("TEAMVER_HTTP_MAX_RETRIES", "2")),
            retry_backoff_seconds=float(os.getenv("TEAMVER_HTTP_RETRY_BACKOFF_SECONDS", "0.25")),
            auth_cookie_name=os.getenv("TEAMVER_AUTH_COOKIE_NAME", "teamver_access_token"),
        )

    @field_validator("api_base_url")
    @classmethod
    def normalize_api_base_url(cls, value: str) -> str:
        trimmed = value.strip().rstrip("/")
        if trimmed.endswith("/api"):
            return trimmed[: -len("/api")]
        return trimmed


class TeamverM2MConfig(BaseModel):
    api_base_url: str
    internal_api_key: str
    timeout_seconds: float = Field(default=10.0, gt=0)
    max_retries: int = Field(default=2, ge=0)
    retry_backoff_seconds: float = Field(default=0.25, ge=0)
    user_agent: str = "teamver-app-sdk-python/0.1.1"

    @classmethod
    def from_env(cls) -> "TeamverM2MConfig":
        api_base_url = os.getenv("TEAMVER_API_BASE_URL", "").strip()
        if not api_base_url:
            raise ValueError("TEAMVER_API_BASE_URL is required")
        internal_api_key = os.getenv("TEAMVER_INTERNAL_API_KEY", "").strip()
        if not internal_api_key:
            raise ValueError("TEAMVER_INTERNAL_API_KEY is required")
        return cls(
            api_base_url=api_base_url,
            internal_api_key=internal_api_key,
            timeout_seconds=float(os.getenv("TEAMVER_HTTP_TIMEOUT_SECONDS", "10")),
            max_retries=int(os.getenv("TEAMVER_HTTP_MAX_RETRIES", "2")),
            retry_backoff_seconds=float(os.getenv("TEAMVER_HTTP_RETRY_BACKOFF_SECONDS", "0.25")),
        )

    @field_validator("api_base_url")
    @classmethod
    def normalize_api_base_url(cls, value: str) -> str:
        return TeamverAppConfig.normalize_api_base_url(value)
