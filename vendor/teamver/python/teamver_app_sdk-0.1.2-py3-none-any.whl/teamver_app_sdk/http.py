from __future__ import annotations

import asyncio
import random
import uuid
from typing import Any

import httpx

from teamver_app_sdk.config import TeamverAppConfig, TeamverM2MConfig
from teamver_app_sdk.enums import ApiRouteLayer
from teamver_app_sdk.errors import MainBEUnavailableError, map_http_error


RETRYABLE_STATUS_CODES = {429, 502, 503, 504}


def _normalize_path_and_layer(
    path: str,
    layer: ApiRouteLayer | None,
) -> tuple[str, ApiRouteLayer]:
    if path.startswith("/api/"):
        return path[len("/api") :], ApiRouteLayer.V1
    if layer is not None:
        if not path.startswith("/"):
            path = f"/{path}"
        return path, layer
    if path.startswith("/internal"):
        return path, ApiRouteLayer.ROOT
    if not path.startswith("/"):
        path = f"/{path}"
    return path, ApiRouteLayer.V1


class TeamverHTTPClient:
    """Async HTTP transport with ROOT + V1 bases (aligned with teamver-be-sdk)."""

    def __init__(
        self,
        config: TeamverAppConfig | TeamverM2MConfig,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.config = config
        common = {
            "timeout": config.timeout_seconds,
            "transport": transport,
            "headers": {"User-Agent": config.user_agent},
        }
        host = config.api_base_url.rstrip("/")
        self._root = httpx.AsyncClient(base_url=host, **common)
        self._v1 = httpx.AsyncClient(base_url=f"{host}/api", **common)

    @property
    def api_v1_base(self) -> str:
        return f"{self.config.api_base_url.rstrip('/')}/api"

    async def aclose(self) -> None:
        await self._root.aclose()
        await self._v1.aclose()

    def _client_for(self, layer: ApiRouteLayer) -> httpx.AsyncClient:
        if layer == ApiRouteLayer.V1:
            return self._v1
        return self._root

    async def get(
        self,
        path: str,
        *,
        access_token: str | None = None,
        workspace_id: str | None = None,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        layer: ApiRouteLayer | None = None,
    ) -> Any:
        return await self.request(
            "GET",
            path,
            access_token=access_token,
            workspace_id=workspace_id,
            headers=headers,
            params=params,
            layer=layer,
        )

    async def post(
        self,
        path: str,
        *,
        json: Any = None,
        access_token: str | None = None,
        workspace_id: str | None = None,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        layer: ApiRouteLayer | None = None,
    ) -> Any:
        return await self.request(
            "POST",
            path,
            json=json,
            access_token=access_token,
            workspace_id=workspace_id,
            headers=headers,
            params=params,
            layer=layer,
        )

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        access_token: str | None = None,
        workspace_id: str | None = None,
        headers: dict[str, str] | None = None,
        params: dict[str, Any] | None = None,
        layer: ApiRouteLayer | None = None,
    ) -> Any:
        path, resolved_layer = _normalize_path_and_layer(path, layer)
        if not path.startswith("/"):
            path = f"/{path}"
        request_headers = self._build_headers(
            access_token=access_token,
            workspace_id=workspace_id,
            headers=headers,
        )
        client = self._client_for(resolved_layer)
        last_exc: Exception | None = None
        for attempt in range(self.config.max_retries + 1):
            try:
                response = await client.request(
                    method,
                    path,
                    json=json,
                    headers=request_headers,
                    params=params,
                )
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                last_exc = exc
                if attempt >= self.config.max_retries:
                    raise MainBEUnavailableError(
                        str(exc),
                        code=exc.__class__.__name__,
                    ) from exc
                await self._sleep_before_retry(attempt)
                continue

            if response.status_code < 400:
                return self._decode_response(response)

            if (
                response.status_code in RETRYABLE_STATUS_CODES
                and attempt < self.config.max_retries
            ):
                await self._sleep_before_retry(attempt)
                continue

            raise map_http_error(response.status_code, self._decode_response(response))

        raise MainBEUnavailableError(str(last_exc or "request failed"))

    def _build_headers(
        self,
        *,
        access_token: str | None,
        workspace_id: str | None,
        headers: dict[str, str] | None,
    ) -> dict[str, str]:
        out = dict(headers or {})
        app_key = getattr(self.config, "app_key", None)
        if app_key:
            out.setdefault("X-Teamver-App-Key", str(app_key))
        out.setdefault("X-Teamver-Request-Id", str(uuid.uuid4()))
        if access_token:
            out["Authorization"] = f"Bearer {access_token}"
        if workspace_id:
            out["X-Workspace-Id"] = workspace_id
        internal_api_key = getattr(self.config, "internal_api_key", None)
        if internal_api_key:
            out["X-Teamver-Internal-Api-Key"] = str(internal_api_key)
        return out

    async def _sleep_before_retry(self, attempt: int) -> None:
        if self.config.retry_backoff_seconds <= 0:
            return
        base_delay = self.config.retry_backoff_seconds * (2**attempt)
        jitter = random.uniform(0, base_delay * 0.25)
        await asyncio.sleep(base_delay + jitter)

    @staticmethod
    def _decode_response(response: httpx.Response) -> Any:
        if not response.content:
            return None
        content_type = response.headers.get("content-type", "")
        if "application/json" in content_type:
            return response.json()
        return response.text
