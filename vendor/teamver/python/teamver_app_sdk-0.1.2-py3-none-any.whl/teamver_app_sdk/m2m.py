from __future__ import annotations

import secrets
from typing import Any

import httpx

from teamver_app_sdk.categories.internal_m2m import InternalM2mApi
from teamver_app_sdk.config import TeamverM2MConfig
from teamver_app_sdk.errors import InvalidInternalApiKey, TeamverInternalKeyNotConfigured
from teamver_app_sdk.http import TeamverHTTPClient


class TeamverM2MClient:
    def __init__(
        self,
        config: TeamverM2MConfig,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.config = config
        self.http = TeamverHTTPClient(config, transport=transport)
        self.internal_m2m = InternalM2mApi(self.http)

    @classmethod
    def from_env(
        cls,
        *,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> "TeamverM2MClient":
        return cls(TeamverM2MConfig.from_env(), transport=transport)

    def auth_headers(self) -> dict[str, str]:
        return {"X-Teamver-Internal-Api-Key": self.config.internal_api_key}

    async def health(self) -> dict[str, Any]:
        return await self.internal_m2m.health()

    async def aclose(self) -> None:
        await self.http.aclose()

    async def __aenter__(self) -> "TeamverM2MClient":
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()


def verify_internal_api_key(*, provided: str | None, expected: str) -> None:
    if not expected:
        raise TeamverInternalKeyNotConfigured(
            "teamver.internal_api_key_not_configured",
            code="teamver.internal_api_key_not_configured",
        )
    if not secrets.compare_digest(provided or "", expected):
        raise InvalidInternalApiKey(
            "teamver.invalid_internal_api_key",
            code="teamver.invalid_internal_api_key",
        )
