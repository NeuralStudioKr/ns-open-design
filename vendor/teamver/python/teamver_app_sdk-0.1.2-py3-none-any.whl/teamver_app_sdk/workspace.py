from __future__ import annotations

from teamver_app_sdk.categories.internal_apps import InternalAppsApi
from teamver_app_sdk.config import TeamverAppConfig
from teamver_app_sdk.errors import AppDisabledError, PermissionDeniedError
from teamver_app_sdk.http import TeamverHTTPClient
from teamver_app_sdk.models import WorkspacePermissions


OWNER_ROLES = {"owner"}
MANAGER_ROLES = {"owner", "admin", "manager"}
MEMBER_ROLES = {"owner", "admin", "manager", "member"}


class WorkspaceClient:
    def __init__(
        self,
        *,
        config: TeamverAppConfig,
        http: TeamverHTTPClient,
        internal_apps: InternalAppsApi | None = None,
    ) -> None:
        self.config = config
        self.http = http
        self._internal_apps = internal_apps or InternalAppsApi(config, http)

    async def get_permissions(
        self,
        *,
        access_token: str,
        workspace_id: str,
    ) -> WorkspacePermissions:
        return await self._internal_apps.workspace_permissions(
            access_token=access_token,
            workspace_id=workspace_id,
        )

    async def require_member(
        self,
        *,
        access_token: str,
        workspace_id: str,
    ) -> WorkspacePermissions:
        permissions = await self.get_permissions(
            access_token=access_token,
            workspace_id=workspace_id,
        )
        if not permissions.is_member:
            raise PermissionDeniedError(
                "workspace.not_member",
                code="workspace.not_member",
                params={"workspace_id": workspace_id},
            )
        return permissions

    async def require_role(
        self,
        *,
        access_token: str,
        workspace_id: str,
        roles: set[str],
    ) -> WorkspacePermissions:
        permissions = await self.require_member(
            access_token=access_token,
            workspace_id=workspace_id,
        )
        normalized = {role.lower() for role in roles}
        role = (permissions.role or "").lower()
        if role not in normalized:
            raise PermissionDeniedError(
                "workspace.role_denied",
                code="workspace.role_denied",
                params={
                    "workspace_id": workspace_id,
                    "required_roles": sorted(normalized),
                    "actual_role": permissions.role,
                },
            )
        return permissions

    async def require_app_enabled(
        self,
        *,
        access_token: str,
        workspace_id: str,
    ) -> WorkspacePermissions:
        """Perform a live app-enabled permission check for sensitive operations."""
        permissions = await self.require_member(
            access_token=access_token,
            workspace_id=workspace_id,
        )
        if not permissions.app_enabled:
            raise AppDisabledError(
                permissions.app_disabled_reason or "app.disabled",
                code=permissions.app_disabled_reason or "app.disabled",
                params={"workspace_id": workspace_id, "app_key": self.config.app_key},
            )
        return permissions
