from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Generic, Protocol, TypeVar


T = TypeVar("T")


class CacheBackend(Protocol):
    async def get(self, key: str) -> object | None: ...

    async def set(
        self,
        key: str,
        value: object,
        *,
        ttl_seconds: int | None = None,
    ) -> None: ...

    async def delete(self, key: str) -> None: ...

    async def clear(self) -> None: ...


@dataclass
class CacheEntry(Generic[T]):
    value: T
    expires_at: float


class TTLCache:
    def __init__(self, default_ttl_seconds: int = 120) -> None:
        self.default_ttl_seconds = default_ttl_seconds
        self._items: dict[str, CacheEntry[object]] = {}

    def get(self, key: str, *, now: float | None = None) -> object | None:
        current = time.monotonic() if now is None else now
        entry = self._items.get(key)
        if entry is None:
            return None
        if entry.expires_at <= current:
            self._items.pop(key, None)
            return None
        return entry.value

    def set(
        self,
        key: str,
        value: object,
        *,
        ttl_seconds: int | None = None,
        now: float | None = None,
    ) -> None:
        ttl = self.default_ttl_seconds if ttl_seconds is None else ttl_seconds
        if ttl <= 0:
            self._items.pop(key, None)
            return
        current = time.monotonic() if now is None else now
        self._items[key] = CacheEntry(value=value, expires_at=current + ttl)

    def delete(self, key: str) -> None:
        self._items.pop(key, None)

    def clear(self) -> None:
        self._items.clear()


class InMemoryCacheBackend:
    def __init__(self, default_ttl_seconds: int = 120) -> None:
        self._cache = TTLCache(default_ttl_seconds=default_ttl_seconds)

    async def get(self, key: str) -> object | None:
        return self._cache.get(key)

    async def set(
        self,
        key: str,
        value: object,
        *,
        ttl_seconds: int | None = None,
    ) -> None:
        self._cache.set(key, value, ttl_seconds=ttl_seconds)

    async def delete(self, key: str) -> None:
        self._cache.delete(key)

    async def clear(self) -> None:
        self._cache.clear()
