from __future__ import annotations

from typing import Any

from teamver_app_sdk.categories.base import CategoryClient
from teamver_app_sdk.config import TeamverAppConfig
from teamver_app_sdk.enums import ApiRouteLayer, AppSdkCategoryId
from teamver_app_sdk.models import AppBootstrap, TeamverUser, WorkspacePermissions


class InternalAppsApi(CategoryClient):
    """03 §3.18 `internal_apps` — bootstrap, me, live permissions."""

    category_id = AppSdkCategoryId.INTERNAL_APPS
    api_layer = ApiRouteLayer.ROOT

    def __init__(self, config: TeamverAppConfig, http: Any) -> None:
        super().__init__(http)
        self._config = config

    @property
    def app_key(self) -> str:
        return str(self._config.app_key)

    async def bootstrap(self, *, access_token: str) -> AppBootstrap:
        data = await self.get(
            f"/internal/apps/{self.app_key}/bootstrap",
            access_token=access_token,
        )
        return AppBootstrap.model_validate(data)

    async def me(self, *, access_token: str) -> TeamverUser:
        data = await self.get(
            f"/internal/apps/{self.app_key}/me",
            access_token=access_token,
        )
        if isinstance(data, dict) and "user" in data:
            return TeamverUser.model_validate(data["user"])
        return TeamverUser.model_validate(data)

    async def workspace_permissions(
        self,
        *,
        access_token: str,
        workspace_id: str,
    ) -> WorkspacePermissions:
        data = await self.get(
            f"/internal/workspaces/{workspace_id}/permissions/{self.app_key}",
            access_token=access_token,
        )
        return WorkspacePermissions.model_validate(data)
