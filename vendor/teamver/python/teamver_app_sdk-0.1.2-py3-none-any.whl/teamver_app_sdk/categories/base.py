from __future__ import annotations

from typing import Any

from teamver_app_sdk.enums import ApiRouteLayer, AppSdkCategoryId
from teamver_app_sdk.http import TeamverHTTPClient


class CategoryClient:
    """Base for app-sdk category APIs (mirrors teamver-be-sdk `CategoryClient`)."""

    category_id: AppSdkCategoryId
    api_layer: ApiRouteLayer = ApiRouteLayer.V1

    def __init__(self, http: TeamverHTTPClient) -> None:
        self._http = http

    async def request(
        self,
        method: str,
        path: str,
        *,
        access_token: str | None = None,
        workspace_id: str | None = None,
        json: Any = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        layer: ApiRouteLayer | None = None,
        **kwargs: Any,
    ) -> Any:
        return await self._http.request(
            method,
            path,
            access_token=access_token,
            workspace_id=workspace_id,
            json=json,
            params=params,
            headers=headers,
            layer=layer or self.api_layer,
            **kwargs,
        )

    async def get(self, path: str, **kwargs: Any) -> Any:
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> Any:
        return await self.request("POST", path, **kwargs)
