from __future__ import annotations

from typing import Any

from teamver_app_sdk.categories.base import CategoryClient
from teamver_app_sdk.enums import ApiRouteLayer, AppSdkCategoryId
from teamver_app_sdk.models import DriveAsset, DriveDownloadUrl, DriveUploadTicket


class DriveV1Api(CategoryClient):
    """03 Drive presigned flow — v1 paths under `/api` (SDK path prefix `/drive`)."""

    category_id = AppSdkCategoryId.DRIVE_V1
    api_layer = ApiRouteLayer.V1

    async def upload_request(
        self,
        *,
        access_token: str,
        filename: str,
        file_size: int,
        content_type: str = "application/octet-stream",
        folder_id: str | None = None,
        shared_drive_id: str | None = None,
        kind: str | None = None,
    ) -> DriveUploadTicket:
        payload: dict[str, object] = {
            "filename": filename,
            "file_size": file_size,
            "content_type": content_type,
            "folder_id": folder_id,
            "shared_drive_id": shared_drive_id,
        }
        if kind:
            payload["kind"] = kind
        data = await self.post(
            "/drive/upload-request",
            access_token=access_token,
            json=payload,
        )
        return DriveUploadTicket.model_validate(data)

    async def upload_confirm(self, *, access_token: str, asset_id: str) -> DriveAsset:
        data = await self.post(
            "/drive/upload-confirm",
            access_token=access_token,
            json={"asset_id": asset_id},
        )
        return DriveAsset.model_validate(data)

    async def download_url(self, *, access_token: str, asset_id: str) -> DriveDownloadUrl:
        data = await self.get(
            f"/drive/asset/{asset_id}/download-url",
            access_token=access_token,
        )
        return DriveDownloadUrl.model_validate(data)

    async def request(self, method: str, path: str, **kwargs: Any) -> Any:
        """Escape hatch for additional drive v1 routes in 03."""
        if not path.startswith("/drive"):
            path = f"/drive{path}" if path.startswith("/") else f"/drive/{path}"
        return await super().request(method, path, **kwargs)
