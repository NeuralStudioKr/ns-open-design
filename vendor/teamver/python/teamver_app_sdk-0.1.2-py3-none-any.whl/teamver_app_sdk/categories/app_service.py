from __future__ import annotations

from typing import Any

from teamver_app_sdk.registry import AppServiceRegistryCredentials, registry_headers
from teamver_app_sdk.categories.base import CategoryClient
from teamver_app_sdk.enums import ApiRouteLayer, AppSdkCategoryId


class AppServiceApi(CategoryClient):
    """03 `ai_apps` — `/api/app-service/*` registry runtime."""

    category_id = AppSdkCategoryId.AI_APPS
    api_layer = ApiRouteLayer.V1

    async def verify_context(
        self,
        *,
        access_token: str,
        workspace_id: str,
        app_id: str,
        credentials: AppServiceRegistryCredentials,
    ) -> dict[str, Any]:
        return await self.post(
            "/app-service/context/verify",
            json={"workspace_id": workspace_id, "app_id": app_id},
            access_token=access_token,
            workspace_id=workspace_id,
            headers=registry_headers(credentials),
        )

    async def heartbeat(
        self,
        app_id: str,
        *,
        status: str,
        version: str | None = None,
        metadata: dict[str, Any] | None = None,
        credentials: AppServiceRegistryCredentials,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"status": status}
        if version is not None:
            body["version"] = version
        if metadata is not None:
            body["metadata"] = metadata
        return await self.post(
            f"/app-service/apps/{app_id}/heartbeat",
            json=body,
            headers=registry_headers(credentials),
        )

    async def usage_report(
        self,
        app_id: str,
        *,
        workspace_id: str,
        user_id: str,
        usage_type: str,
        quantity: int = 1,
        unit: str = "job",
        metadata: dict[str, Any] | None = None,
        credentials: AppServiceRegistryCredentials,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "workspace_id": workspace_id,
            "user_id": user_id,
            "usage_type": usage_type,
            "quantity": quantity,
            "unit": unit,
        }
        if metadata is not None:
            body["metadata"] = metadata
        return await self.post(
            f"/app-service/apps/{app_id}/usage-report",
            json=body,
            headers=registry_headers(credentials),
        )

    async def post_event(
        self,
        *,
        workspace_id: str,
        event_type: str,
        credentials: AppServiceRegistryCredentials,
        app_id: str | None = None,
        user_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        audit: bool = False,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "workspace_id": workspace_id,
            "event_type": event_type,
        }
        if app_id is not None:
            body["app_id"] = app_id
        if user_id is not None:
            body["user_id"] = user_id
        if metadata is not None:
            body["metadata"] = metadata
        path = "/audit/events" if audit else "/app-service/events"
        return await self.post(path, json=body, headers=registry_headers(credentials))
