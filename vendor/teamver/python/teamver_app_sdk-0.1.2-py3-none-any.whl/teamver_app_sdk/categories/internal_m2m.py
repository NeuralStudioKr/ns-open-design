from __future__ import annotations

from typing import Any

from teamver_app_sdk.categories.base import CategoryClient
from teamver_app_sdk.enums import ApiRouteLayer, AppSdkCategoryId


class InternalM2mApi(CategoryClient):
    """03 §3.19 `internal_m2m`."""

    category_id = AppSdkCategoryId.INTERNAL_M2M
    api_layer = ApiRouteLayer.ROOT

    async def health(self) -> dict[str, Any]:
        data = await self.get("/internal/m2m/health")
        return data if isinstance(data, dict) else {"data": data}
