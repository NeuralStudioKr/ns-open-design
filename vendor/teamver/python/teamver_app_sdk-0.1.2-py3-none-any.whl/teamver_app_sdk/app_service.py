"""`/api/app-service/*` — Registry runtime (03 `ai_apps`, docs/116 §9)."""

from __future__ import annotations

from typing import Any

from teamver_app_sdk.categories.app_service import AppServiceApi
from teamver_app_sdk.http import TeamverHTTPClient
from teamver_app_sdk.registry import AppServiceRegistryCredentials

__all__ = ["AppServiceClient", "AppServiceRegistryCredentials"]


class AppServiceClient:
    def __init__(self, http: TeamverHTTPClient) -> None:
        self._api = AppServiceApi(http)

    async def verify_context(
        self,
        *,
        access_token: str,
        workspace_id: str,
        app_id: str,
        credentials: AppServiceRegistryCredentials,
    ) -> dict[str, Any]:
        return await self._api.verify_context(
            access_token=access_token,
            workspace_id=workspace_id,
            app_id=app_id,
            credentials=credentials,
        )

    async def heartbeat(
        self,
        app_id: str,
        *,
        status: str,
        version: str | None = None,
        metadata: dict[str, Any] | None = None,
        credentials: AppServiceRegistryCredentials,
    ) -> dict[str, Any]:
        return await self._api.heartbeat(
            app_id,
            status=status,
            version=version,
            metadata=metadata,
            credentials=credentials,
        )

    async def usage_report(
        self,
        app_id: str,
        *,
        workspace_id: str,
        user_id: str,
        usage_type: str,
        quantity: int = 1,
        unit: str = "job",
        metadata: dict[str, Any] | None = None,
        credentials: AppServiceRegistryCredentials,
    ) -> dict[str, Any]:
        return await self._api.usage_report(
            app_id,
            workspace_id=workspace_id,
            user_id=user_id,
            usage_type=usage_type,
            quantity=quantity,
            unit=unit,
            metadata=metadata,
            credentials=credentials,
        )

    async def post_event(
        self,
        *,
        workspace_id: str,
        event_type: str,
        credentials: AppServiceRegistryCredentials,
        app_id: str | None = None,
        user_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        audit: bool = False,
    ) -> dict[str, Any]:
        return await self._api.post_event(
            workspace_id=workspace_id,
            event_type=event_type,
            credentials=credentials,
            app_id=app_id,
            user_id=user_id,
            metadata=metadata,
            audit=audit,
        )
