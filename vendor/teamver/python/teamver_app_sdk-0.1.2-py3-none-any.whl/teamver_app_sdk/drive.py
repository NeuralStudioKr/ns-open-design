from __future__ import annotations

import httpx

from teamver_app_sdk.categories.drive_v1 import DriveV1Api
from teamver_app_sdk.errors import (
    DriveConfirmError,
    DriveDownloadError,
    DriveUploadError,
    TeamverAPIError,
)
from teamver_app_sdk.http import TeamverHTTPClient
from teamver_app_sdk.models import DriveAsset, DriveDownloadUrl, DriveUploadTicket


class DriveClient:
    def __init__(
        self,
        *,
        http: TeamverHTTPClient,
        drive_api: DriveV1Api | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
        timeout_seconds: float = 30.0,
    ) -> None:
        self.http = http
        self._drive_api = drive_api or DriveV1Api(http)
        self._binary_client = httpx.AsyncClient(
            timeout=timeout_seconds,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self._binary_client.aclose()

    async def create_upload_request(
        self,
        *,
        access_token: str,
        filename: str,
        file_size: int,
        content_type: str = "application/octet-stream",
        folder_id: str | None = None,
        shared_drive_id: str | None = None,
        kind: str | None = None,
    ) -> DriveUploadTicket:
        return await self._drive_api.upload_request(
            access_token=access_token,
            filename=filename,
            file_size=file_size,
            content_type=content_type,
            folder_id=folder_id,
            shared_drive_id=shared_drive_id,
            kind=kind,
        )

    async def confirm_upload(
        self,
        *,
        access_token: str,
        asset_id: str,
    ) -> DriveAsset:
        try:
            return await self._drive_api.upload_confirm(
                access_token=access_token,
                asset_id=asset_id,
            )
        except TeamverAPIError as exc:
            raise DriveConfirmError(
                str(exc),
                status_code=exc.status_code,
                code=exc.code,
                params=exc.params,
                response_body=exc.response_body,
            ) from exc

    async def create_download_url(
        self,
        *,
        access_token: str,
        asset_id: str,
    ) -> DriveDownloadUrl:
        return await self._drive_api.download_url(
            access_token=access_token,
            asset_id=asset_id,
        )

    async def upload_bytes_to_personal_drive(
        self,
        *,
        access_token: str,
        filename: str,
        content: bytes,
        content_type: str = "application/octet-stream",
        folder_id: str | None = None,
    ) -> DriveAsset:
        ticket = await self.create_upload_request(
            access_token=access_token,
            filename=filename,
            file_size=len(content),
            content_type=content_type,
            folder_id=folder_id,
        )
        await self._put_presigned_bytes(
            ticket.presigned_url,
            content=content,
            content_type=content_type,
        )
        return await self.confirm_upload(access_token=access_token, asset_id=ticket.asset_id)

    async def download_bytes(
        self,
        *,
        access_token: str,
        asset_id: str,
        max_bytes: int | None = None,
    ) -> bytes:
        download = await self.create_download_url(access_token=access_token, asset_id=asset_id)
        try:
            async with self._binary_client.stream("GET", download.download_url) as response:
                if response.status_code >= 400:
                    body = await response.aread()
                    raise DriveDownloadError(
                        f"presigned download failed with status {response.status_code}",
                        status_code=response.status_code,
                        response_body=body.decode("utf-8", errors="replace"),
                    )
                content = bytearray()
                async for chunk in response.aiter_bytes():
                    content.extend(chunk)
                    if max_bytes is not None and len(content) > max_bytes:
                        raise DriveDownloadError(
                            (
                                "presigned download exceeded max_bytes limit "
                                f"({len(content)} > {max_bytes})"
                            ),
                            code="drive.download_too_large",
                        )
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            raise DriveDownloadError(str(exc), code=exc.__class__.__name__) from exc
        return bytes(content)

    async def _put_presigned_bytes(
        self,
        presigned_url: str,
        *,
        content: bytes,
        content_type: str,
    ) -> None:
        try:
            response = await self._binary_client.put(
                presigned_url,
                content=content,
                headers={"Content-Type": content_type},
            )
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            raise DriveUploadError(str(exc), code=exc.__class__.__name__) from exc
        if response.status_code >= 400:
            raise DriveUploadError(
                f"S3 PUT failed with status {response.status_code}",
                status_code=response.status_code,
                response_body=response.text,
            )
