import httpx

from teamver_app_sdk.audit import AuditClient
from teamver_app_sdk.app_service import AppServiceClient
from teamver_app_sdk.auth import AuthClient
from teamver_app_sdk.billing import BillingClient
from teamver_app_sdk.cache import CacheBackend
from teamver_app_sdk.categories.app_service import AppServiceApi
from teamver_app_sdk.categories.drive_v1 import DriveV1Api
from teamver_app_sdk.categories.internal_apps import InternalAppsApi
from teamver_app_sdk.config import AppKey, TeamverAppConfig
from teamver_app_sdk.drive import DriveClient
from teamver_app_sdk.http import TeamverHTTPClient
from teamver_app_sdk.workspace import WorkspaceClient


class TeamverAppClient:
    """Facade for AI App BE integration (high-level clients + 03 category APIs)."""

    def __init__(
        self,
        config: TeamverAppConfig,
        *,
        cache: CacheBackend | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.config = config
        self.http = TeamverHTTPClient(config, transport=transport)
        self.internal_apps = InternalAppsApi(config, self.http)
        self.drive_v1 = DriveV1Api(self.http)
        self.app_service_api = AppServiceApi(self.http)
        self.app_service = AppServiceClient(self.http)
        self.auth = AuthClient(
            config=config,
            http=self.http,
            cache=cache,
            internal_apps=self.internal_apps,
        )
        self.workspace = WorkspaceClient(
            config=config,
            http=self.http,
            internal_apps=self.internal_apps,
        )
        self.drive = DriveClient(http=self.http, drive_api=self.drive_v1, transport=transport)
        self.billing = BillingClient(self.http)
        self.audit = AuditClient(self.http)

    @classmethod
    def from_env(
        cls,
        *,
        app_key: AppKey | str | None = None,
        cache: CacheBackend | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> "TeamverAppClient":
        resolved: AppKey | None = None
        if app_key is not None:
            resolved = app_key if isinstance(app_key, AppKey) else AppKey(app_key)
        return cls(
            TeamverAppConfig.from_env(app_key=resolved),
            cache=cache,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self.drive.aclose()
        await self.http.aclose()

    async def __aenter__(self) -> "TeamverAppClient":
        return self

    async def __aexit__(self, *exc_info: object) -> None:
        await self.aclose()
