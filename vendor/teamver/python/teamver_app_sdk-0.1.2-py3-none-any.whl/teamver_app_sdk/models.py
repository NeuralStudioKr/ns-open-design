from __future__ import annotations

from pydantic import BaseModel, Field, field_serializer

from teamver_app_sdk.errors import WorkspaceNotFoundError


class TeamverUser(BaseModel):
    user_id: str
    email: str
    display_name: str | None = None
    image_url: str | None = None


class TeamverWorkspace(BaseModel):
    workspace_id: str
    name: str | None = None
    role: str
    membership_status: str = "active"
    is_account_default_workspace: bool
    is_workspace_owner: bool = False
    plan_id: str | None = None
    plan_name: str | None = None
    subscription_status: str | None = None
    member_count: int = 0
    app_enabled: bool = True
    app_disabled_reason: str | None = None


class AppBootstrap(BaseModel):
    app_key: str
    user: TeamverUser
    default_workspace_id: str | None = None
    workspaces: list[TeamverWorkspace] = Field(default_factory=list)

    def get_workspace(self, workspace_id: str) -> TeamverWorkspace | None:
        target = workspace_id.strip()
        for workspace in self.workspaces:
            if workspace.workspace_id == target:
                return workspace
        return None

    def require_workspace(self, workspace_id: str) -> TeamverWorkspace:
        workspace = self.get_workspace(workspace_id)
        if workspace is None:
            raise WorkspaceNotFoundError(
                "workspace.not_found",
                code="workspace.not_found",
                params={"workspace_id": workspace_id},
            )
        return workspace


class WorkspacePermissions(BaseModel):
    workspace_id: str
    app_key: str
    user_id: str
    is_member: bool
    role: str | None = None
    is_workspace_owner: bool = False
    membership_status: str = "active"
    app_enabled: bool
    app_disabled_reason: str | None = None
    plan_id: str | None = None
    plan_name: str | None = None
    subscription_status: str | None = None


class DriveUploadRequest(BaseModel):
    filename: str
    file_size: int
    content_type: str = "application/octet-stream"
    folder_id: str | None = None
    shared_drive_id: str | None = None


class DriveUploadTicket(BaseModel):
    asset_id: str
    blob_id: str | None = None
    presigned_url: str
    s3_key: str | None = None
    expires_in: int = 300


class DriveAsset(BaseModel):
    asset_id: str
    name: str | None = None
    upload_status: str | None = None
    message: str | None = None
    size_bytes: int | None = None


class DriveDownloadUrl(BaseModel):
    download_url: str
    filename: str | None = None
    content_type: str | None = None
    expires_in: int = 300


class AppContext(BaseModel):
    """Resolved app context for standard request flow.

    `bootstrap` may contain all user workspaces from a short-lived cache.
    Use `WorkspaceClient` for sensitive mutations that require live permission checks.
    """

    app_key: str
    access_token: str = Field(repr=False)
    user: TeamverUser
    workspace: TeamverWorkspace
    bootstrap: AppBootstrap

    @field_serializer("access_token")
    def _serialize_access_token(self, value: str) -> str:
        if len(value) <= 8:
            return "[redacted]"
        return f"{value[:8]}...[redacted]"

    @property
    def user_id(self) -> str:
        return self.user.user_id

    @property
    def workspace_id(self) -> str:
        return self.workspace.workspace_id
