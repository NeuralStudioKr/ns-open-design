from __future__ import annotations

import hashlib
import base64
import json

from teamver_app_sdk.cache import CacheBackend, InMemoryCacheBackend
from teamver_app_sdk.categories.internal_apps import InternalAppsApi
from teamver_app_sdk.config import TeamverAppConfig
from teamver_app_sdk.errors import AppDisabledError, AuthenticationError, WorkspaceNotFoundError
from teamver_app_sdk.http import TeamverHTTPClient
from teamver_app_sdk.models import AppBootstrap, AppContext, TeamverUser


class AuthClient:
    def __init__(
        self,
        *,
        config: TeamverAppConfig,
        http: TeamverHTTPClient,
        cache: CacheBackend | None = None,
        internal_apps: InternalAppsApi | None = None,
    ) -> None:
        self.config = config
        self.http = http
        self._internal_apps = internal_apps or InternalAppsApi(config, http)
        self.cache = cache or InMemoryCacheBackend(
            default_ttl_seconds=config.bootstrap_cache_ttl_seconds
        )
        self._token_keys_by_user_id: dict[str, set[str]] = {}

    async def get_bootstrap(
        self,
        *,
        access_token: str,
        use_cache: bool = True,
        force_refresh: bool = False,
    ) -> AppBootstrap:
        if not access_token:
            raise AuthenticationError("auth.missing_access_token", code="auth.missing_access_token")
        token_fingerprint = self._token_fingerprint(access_token)
        token_key = self._token_cache_key(access_token)
        user_id_hint = self._try_unverified_jwt_user_id(access_token)
        canonical_key = self._canonical_cache_key(user_id_hint) if user_id_hint else None
        if use_cache and not force_refresh:
            for key in (token_key, canonical_key):
                if key is None:
                    continue
                cached = await self.cache.get(key)
                bootstrap = self._bootstrap_from_cache_entry(
                    cached,
                    token_fingerprint=token_fingerprint,
                )
                if bootstrap is not None:
                    return bootstrap

        bootstrap = await self._internal_apps.bootstrap(access_token=access_token)
        if use_cache:
            await self._remember_token_key(
                user_id=bootstrap.user.user_id,
                token_key=token_key,
            )
            await self.cache.set(
                token_key,
                bootstrap,
                ttl_seconds=self.config.bootstrap_cache_ttl_seconds,
            )
            await self.cache.set(
                self._canonical_cache_key(bootstrap.user.user_id),
                {
                    "token_fingerprint": token_fingerprint,
                    "bootstrap": bootstrap,
                },
                ttl_seconds=self.config.bootstrap_cache_ttl_seconds,
            )
        return bootstrap

    async def me(self, *, access_token: str) -> TeamverUser:
        return await self._internal_apps.me(access_token=access_token)

    async def resolve_context(
        self,
        *,
        access_token: str,
        workspace_id: str | None = None,
        require_app_enabled: bool = True,
        use_cache: bool = True,
    ) -> AppContext:
        """Resolve standard request context from bootstrap cache.

        This is intended for normal app routes and read-heavy flows. Use
        `client.workspace.require_app_enabled()` for sensitive mutations that
        need a live permissions check immediately before execution.
        """
        bootstrap = await self.get_bootstrap(access_token=access_token, use_cache=use_cache)
        target_workspace_id = (workspace_id or bootstrap.default_workspace_id or "").strip()
        if not target_workspace_id:
            raise WorkspaceNotFoundError("workspace.not_found", code="workspace.not_found")

        workspace = bootstrap.require_workspace(target_workspace_id)
        if require_app_enabled and not workspace.app_enabled:
            raise AppDisabledError(
                workspace.app_disabled_reason or "app.disabled",
                code=workspace.app_disabled_reason or "app.disabled",
                params={"workspace_id": workspace.workspace_id, "app_key": self.config.app_key},
            )
        return AppContext(
            app_key=self.config.app_key,
            access_token=access_token,
            user=bootstrap.user,
            workspace=workspace,
            bootstrap=bootstrap,
        )

    async def invalidate_bootstrap(self, *, user_id: str) -> None:
        indexed_keys = await self.cache.get(self._user_token_index_key(user_id))
        token_keys = set(indexed_keys) if isinstance(indexed_keys, list) else set()
        token_keys.update(self._token_keys_by_user_id.pop(user_id, set()))
        for token_key in token_keys:
            await self.cache.delete(token_key)
        await self.cache.delete(self._user_token_index_key(user_id))
        await self.cache.delete(self._canonical_cache_key(user_id))

    async def invalidate_current(self, *, access_token: str) -> None:
        user_id_hint = self._try_unverified_jwt_user_id(access_token)
        if user_id_hint:
            await self.cache.delete(self._canonical_cache_key(user_id_hint))
        await self.cache.delete(self._token_cache_key(access_token))

    def _token_cache_key(self, access_token: str) -> str:
        return f"apps_bootstrap:{self.config.app_key}:token:{self._token_fingerprint(access_token)}"

    def _canonical_cache_key(self, user_id: str) -> str:
        return f"apps_bootstrap:{self.config.app_key}:{user_id}"

    def _user_token_index_key(self, user_id: str) -> str:
        return f"apps_bootstrap:{self.config.app_key}:{user_id}:token_keys"

    async def _remember_token_key(self, *, user_id: str, token_key: str) -> None:
        self._token_keys_by_user_id.setdefault(user_id, set()).add(token_key)
        index_key = self._user_token_index_key(user_id)
        current = await self.cache.get(index_key)
        token_keys = set(current) if isinstance(current, list) else set()
        token_keys.add(token_key)
        await self.cache.set(
            index_key,
            sorted(token_keys),
            ttl_seconds=self.config.bootstrap_cache_ttl_seconds,
        )

    def _token_fingerprint(self, access_token: str) -> str:
        return hashlib.sha256(access_token.encode("utf-8")).hexdigest()

    def _try_unverified_jwt_user_id(self, access_token: str) -> str | None:
        parts = access_token.split(".")
        if len(parts) != 3:
            return None
        try:
            payload_segment = parts[1]
            padding = "=" * (-len(payload_segment) % 4)
            raw = base64.urlsafe_b64decode(f"{payload_segment}{padding}")
            payload = json.loads(raw)
        except (ValueError, TypeError, json.JSONDecodeError):
            return None
        if not isinstance(payload, dict):
            return None
        value = payload.get("user_id") or payload.get("sub")
        if value is None:
            return None
        user_id = str(value).strip()
        return user_id or None

    def _bootstrap_from_cache_entry(
        self,
        cached: object,
        *,
        token_fingerprint: str,
    ) -> AppBootstrap | None:
        if isinstance(cached, AppBootstrap):
            return cached
        if isinstance(cached, dict):
            fingerprint = cached.get("token_fingerprint")
            bootstrap = cached.get("bootstrap")
            if fingerprint == token_fingerprint and isinstance(bootstrap, AppBootstrap):
                return bootstrap
        return None


def extract_access_token_from_headers(
    *,
    authorization: str | None,
    cookie_token: str | None = None,
) -> str | None:
    if authorization:
        scheme, _, token = authorization.strip().partition(" ")
        if scheme.lower() == "bearer" and token.strip():
            return token.strip()
    if cookie_token and cookie_token.strip():
        return cookie_token.strip()
    return None
