from __future__ import annotations

from typing import Any

from teamver_app_sdk.http import TeamverHTTPClient
from teamver_app_sdk.registry import AppServiceRegistryCredentials, registry_headers


class AuditClient:
    def __init__(self, http: TeamverHTTPClient) -> None:
        self._http = http

    async def log_event(
        self,
        *,
        workspace_id: str,
        event_type: str,
        credentials: AppServiceRegistryCredentials,
        app_id: str | None = None,
        user_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "workspace_id": workspace_id,
            "event_type": event_type,
        }
        if app_id:
            body["app_id"] = app_id
        if user_id:
            body["user_id"] = user_id
        if metadata is not None:
            body["metadata"] = metadata
        return await self._http.post(
            "/audit/events",
            json=body,
            headers=registry_headers(credentials),
        )
