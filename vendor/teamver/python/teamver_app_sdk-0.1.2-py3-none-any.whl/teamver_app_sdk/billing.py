from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from teamver_app_sdk.http import TeamverHTTPClient
from teamver_app_sdk.registry import AppServiceRegistryCredentials, registry_headers


class TokenUsageByModelQuery(BaseModel):
    user_id: str | None = None
    workspace_id: str | None = None
    from_at: datetime | None = None
    to_at: datetime | None = None


class TokenUsageByModelItem(BaseModel):
    model_config = ConfigDict(protected_namespaces=())

    model_name: str
    input_tokens: int = Field(default=0, ge=0)
    output_tokens: int = Field(default=0, ge=0)
    total_tokens: int = Field(default=0, ge=0)

    @model_validator(mode="after")
    def fill_total_tokens(self) -> "TokenUsageByModelItem":
        self.total_tokens = self.input_tokens + self.output_tokens
        return self


class BillingClient:
    def __init__(self, http: TeamverHTTPClient) -> None:
        self._http = http

    @staticmethod
    def serialize_usage_by_model(
        items: list[TokenUsageByModelItem],
    ) -> list[dict[str, int | str]]:
        return [item.model_dump() for item in items]

    async def reserve(
        self,
        *,
        workspace_id: str,
        amount: int,
        credentials: AppServiceRegistryCredentials,
        app_id: str | None = None,
        reason: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"workspace_id": workspace_id, "amount": amount}
        if app_id:
            body["app_id"] = app_id
        if reason:
            body["reason"] = reason
        return await self._http.post(
            "/billing/reserve",
            json=body,
            headers=registry_headers(credentials),
        )

    async def commit(
        self,
        *,
        usage_id: str,
        credentials: AppServiceRegistryCredentials,
    ) -> dict[str, Any]:
        return await self._http.post(
            "/billing/commit",
            json={"usage_id": usage_id},
            headers=registry_headers(credentials),
        )

    async def refund(
        self,
        *,
        usage_id: str,
        credentials: AppServiceRegistryCredentials,
        reason: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"usage_id": usage_id}
        if reason:
            body["reason"] = reason
        return await self._http.post(
            "/billing/refund",
            json=body,
            headers=registry_headers(credentials),
        )
