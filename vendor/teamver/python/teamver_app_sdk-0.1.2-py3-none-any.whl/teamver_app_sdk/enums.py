from __future__ import annotations

from enum import StrEnum


class ApiRouteLayer(StrEnum):
    """HTTP root selection (aligned with teamver-be-sdk `ApiVersion`)."""

    ROOT = "root"
    """Host root — `/internal/*` (03 §3.18 `internal_apps`, §3.19 `internal_m2m`)."""

    V1 = "v1"
    """`{host}/api` — Drive, app-service, billing (03 §3 drive_v1 / `ai_apps` app-service)."""


class AppSdkCategoryId(StrEnum):
    """03 §2 slices implemented by this SDK (AI App BE integration surface)."""

    INTERNAL_APPS = "internal_apps"
    INTERNAL_M2M = "internal_m2m"
    DRIVE_V1 = "drive_v1"
    AI_APPS = "ai_apps"
    USAGE_BILLING = "usage_billing"


class AppKey(StrEnum):
    SLIDES = "slides"
    MEETINGS = "meetings"
    DOCS = "docs"
    IMAGES = "images"
    CHATS = "chats"
    MAIL = "mail"
    DESIGN = "design"
